# Generated test data: methodology

**SIMULATED DATA - CREATED FOR ANALYTICAL TESTING.** These four tables were NOT supplied. They exist only to exercise the KPI formulas for rewards, wallet, withdrawals and referrals. They support no business insight and no statement about VELOOP. Regenerate with `python run.py synthetic` (fixed seed 2026).

| Table | Rows | How it is built | PROPOSED (invented) parts |
|---|---|---|---|
| rewards | about 6,466 | One row per supplied task attempt whose reward_status is Credited or Pending. Amount = base by task_category (2 to 40) x {0.5, 1, 1.5, 2}. 2.5% of credited rewards get a reversal row (original_reward_id), 0.8% a correction row, and 15 are credited twice for the same activity (duplicates). | Unit mix VE 85%, XP 10%, Gems 5%; amount scale; reason categories |
| wallet | 6,869 | One ledger row per credited/reversed/corrected reward (1.5% pending, 1% failed), 6% of users get 1 to 4 redemptions, one debit per non-rejected withdrawal, plus 12 duplicated transaction_id rows | Transaction types; redemption sizes |
| withdrawals | 1,035 (1,200 requested, those after 15 Sep 2026 dropped) | Users chosen by credited VE balance; request time after their first credit; processing delay exponential (mean 6h); finalisation lognormal (median 1.5 days); outcomes: completed 63%, rejected 14%, reversed 3%, left in processing 20%; anything unfinished at 15 Sep 2026 stays open | Method names method_A/B/C (real methods unknown); reason categories; outcome mix |
| referrals | 900 | The 154 users whose supplied acquisition_source is Referral become registered referrals (referrer random). Activation and conversion are derived from their REAL supplied task completions using proposed rule R1. 746 further referrals stay "created" (never registered) | Rule R1: activated = first completed task within 7 days of registration; converted = at least 3 completed tasks within 14 days |

Design intent (brief s.29): not flattering. The data includes rejected, pending, reversed, duplicate and unfinished records. Outcome shares are assumptions chosen only to produce variety.
