# data/raw
Place the two supplied simulated workbooks here (not committed: they contain simulated personal fields such as names and emails and belong to the supplied pack):

- 1793188481774_VELoop_Rewards_Data_01.xlsx
- 1793188525986_VELOOP_Simulated_User_Behavior_1000.xlsx

Then follow "Reproduce everything" in the main README. Data-dependent tests skip automatically if the files are missing.
