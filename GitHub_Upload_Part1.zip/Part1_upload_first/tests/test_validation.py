"""Validation tests: KPI formulas (SQL vs pandas), ER relationships, event pairing investigation, partial weeks, dashboard safety."""
import sys, pathlib, re, pytest, pandas as pd
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from veloop_analytics.config import RAW, FILE_A, FILE_B, ROOT
from veloop_analytics import kpi_engine, kpi_validation, er_validation, insights, synthetic
from veloop_analytics.loaders import load_all
have = (RAW / FILE_A).exists() and (RAW / FILE_B).exists()
pytestmark = pytest.mark.skipif(not have, reason="raw data missing")

@pytest.fixture(scope="module")
def d(): return load_all()
@pytest.fixture(scope="module")
def g(d): return {k: v.drop(columns="data_label") for k, v in synthetic.generate(d).items()}
@pytest.fixture(scope="module")
def kdf(d, g): return kpi_engine.build(d, g)

def test_sql_formulas_equal_independent_pandas_results(d, g, kdf):
    """All 38 SQL test cases give the same number as an independent pandas calculation (supplied and generated data)."""
    cs, rc = kpi_validation.run(d, g, kdf)
    assert len(cs) == 38 and cs.passed.all(), cs[~cs.passed]
    assert len(rc) == 6 and rc.passed.all(), rc[~rc.passed]

def test_every_kpi_has_a_validation_status_and_none_is_production_ready(d, g, kdf):
    """46 KPIs each carry a validation status; none is marked production-ready; no validation failed."""
    cs, rc = kpi_validation.run(d, g, kdf); sm = kpi_validation.summary(kdf, cs, rc)
    assert len(sm) == 46 and sm.kpi_id.is_unique and not sm.validation_status.str.contains("FAILED").any()
    assert sm.production_ready.str.startswith("No").all()

def test_er_relationships_have_expected_results(d, g):
    """Supplied-data relationships pass; tasks catalogue and duplicate credits fail; support tickets are not testable."""
    r = er_validation.run(d, g).set_index(["parent", "child"])
    for k in [("users", "sessions"), ("users", "feature_events"), ("sessions", "feature_events"), ("sessions", "task_activity"), ("users", "task_activity")]:
        assert r.loc[k, "result"] == "PASS (supplied data)", k
    assert r.loc[("tasks", "task_activity"), "result"] == "FAIL" and r.loc[("tasks", "task_activity"), "violations"] == 80
    assert r.loc[("task_activity", "rewards"), "violations"] == 15
    assert r.loc[("withdrawals", "wallet_transactions"), "result"].startswith("PASS")
    assert r.loc[("users", "support_tickets"), "result"] == "NOT TESTABLE"

def test_event_ratio_investigation_event_ids_unique_and_pairing_low(d):
    """Ratios above 1 are not a duplicate artefact (event_id unique, still >1 after dedup) and fewer than 20% of finishes have an earlier start in-session."""
    ins, tabs = insights.compute(d); f = tabs["event_pairing_investigation"]
    assert (f.event_ids_duplicated == 0).all()
    assert (f.set_index("finished").loc[["ad_completed", "spin_completed", "mission_completed", "mining_stopped"], "ratio_after_dedup"] > 1.0).all()
    assert (f.finish_events_with_earlier_start_in_same_session < 0.20).all()
    assert (d["B:03_Feature_Events"].duplicated(["user_id", "session_id", "event_name", "event_datetime"]).sum()) == 138

def test_partial_weeks_are_flagged(d):
    """First week covers 5 days and last week 2 days of the period; both are flagged partial; all other weeks are complete."""
    _, tabs = insights.compute(d); wk = tabs["weekly_active_users"]
    assert wk.partial_week.iloc[0] and wk.partial_week.iloc[-1] and int(wk.days_in_period.iloc[-1]) == 2 and int(wk.days_in_period.iloc[0]) == 5
    assert (~wk.partial_week.iloc[1:-1]).all()

def test_dashboard_is_labelled_aggregate_only_and_marks_partial_weeks():
    """The functional dashboard carries the SIMULATED banner, marks partial weeks, and embeds no email addresses or names."""
    p = ROOT / "dashboard" / "index.html"
    if not p.exists(): pytest.skip("dashboard not built")
    h = p.read_text(); assert "SIMULATED DATA, NOT ACTUAL VELOOP RESULTS" in h and "partial" in h.lower() and "stroke-dasharray" in h
    assert not re.search(r"[\w.]+@[\w.]+\.[a-z]{2,}", h)
