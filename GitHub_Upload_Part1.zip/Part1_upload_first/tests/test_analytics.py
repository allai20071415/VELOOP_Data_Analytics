"""Tests for evidence, KPI review, generated data and insights. Data-dependent tests skip if the raw workbooks are absent."""
import sys, pathlib, pytest, pandas as pd
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from veloop_analytics.config import RAW, FILE_A, FILE_B, ROOT
from veloop_analytics import insights, kpi_engine, synthetic, quality
from veloop_analytics.loaders import load_all
have = (RAW / FILE_A).exists() and (RAW / FILE_B).exists()
needs_data = pytest.mark.skipif(not have, reason="raw data missing")

def test_ztest_known_values():
    """Two-proportion z-test returns p=1 for equal rates and p<0.001 for very different rates."""
    assert insights.ztest(50, 100, 50, 100) == pytest.approx(1.0, abs=1e-9)      # identical proportions
    assert insights.ztest(80, 100, 20, 100) < 0.001                               # very different proportions

def test_kpi_spec_ids_are_unique_and_labelled():
    """All 46 KPIs have an SQL formula and one of the three availability labels."""
    assert len(kpi_engine.SPEC) == 46
    assert {v[2] for v in kpi_engine.SPEC.values()} <= {kpi_engine.AV_OK, kpi_engine.AV_PART, kpi_engine.AV_NO}
    assert all(v[0].upper().startswith("SELECT") for v in kpi_engine.SPEC.values())

@pytest.fixture(scope="module")
def d(): return load_all()

@needs_data
def test_every_evidence_file_matches_reported_count(d):
    """35 issues; 31 have evidence rows and each evidence row count equals the reported record count."""
    rows, ev = quality.run_with_evidence(d)
    assert len(rows) == 35 and len(ev) == 31
    for r in rows:
        if r["issue_id"] in ev: assert len(ev[r["issue_id"]]) == r["records"], r["issue_id"]

@needs_data
def test_generated_data_is_deterministic_labelled_and_unflattering(d):
    """Generated tables are identical across runs (seed), carry the SIMULATED label, and include failures and duplicates."""
    a, b = synthetic.generate(d), synthetic.generate(d)
    for k in a: pd.testing.assert_frame_equal(a[k], b[k])
    assert all((v.data_label == synthetic.LABEL).all() for v in a.values())
    w = a["withdrawals"]; assert {"completed", "rejected", "reversed", "processing"} <= set(w.status)       # failures and open items exist
    assert a["wallet"].transaction_id.duplicated().sum() == 12 and a["rewards"].reward_id.is_unique

@needs_data
def test_kpi_review_covers_all_46_and_runs_on_both_data_sets(d):
    """KPI review has 46 unique rows; calculable KPIs have values; not-calculable KPIs never carry an invented supplied value."""
    g = {k: pd.read_csv(ROOT / "data" / "synthetic" / f"{k}.csv") for k in ["rewards", "wallet", "withdrawals", "referrals"]} if (ROOT / "data" / "synthetic" / "rewards.csv").exists() else {k: v.drop(columns="data_label") for k, v in synthetic.generate(d).items()}
    df = kpi_engine.build(d, g)
    assert len(df) == 46 and df.kpi_id.is_unique
    ok = df[df.availability == kpi_engine.AV_OK]; assert (ok.value_on_supplied_simulated_data.str.len() > 0).all()
    no = df[df.availability == kpi_engine.AV_NO]; assert (no.value_on_supplied_simulated_data == "").all()     # never invent supplied-data values

@needs_data
def test_insights_are_computed_and_free_of_nan(d):
    """11 insights are computed and none contains NaN text."""
    ins, tabs = insights.compute(d)
    assert len(ins) == 11 and all("nan" not in i[2].lower() for i in ins) and len(tabs) >= 8
