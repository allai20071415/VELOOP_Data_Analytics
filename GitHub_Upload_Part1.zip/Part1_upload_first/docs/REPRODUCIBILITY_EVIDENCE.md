# Reproducibility evidence

All results describe SIMULATED or GENERATED data. Verified on a clean copy (fresh folder, project files copied without outputs, evidence or generated data; the two supplied workbooks added to data/raw).

| Step | Command | Result |
|---|---|---|
| Tests without the data files | python -m pytest -q tests | 7 passed, 16 skipped (data-dependent tests skip by design) |
| Design workbook | python scripts/design_workbook/build.py | 38 events, 46 KPIs, 100 dictionary fields |
| Full pipeline | python run.py all | 31 evidence files; generated tables rewards 6,466, wallet 6,869, withdrawals 1,035, referrals 900; KPI review 17 calculable / 11 proxy / 18 not calculable; KPI validation 0 failed cases; ER validation 7 + 8 pass, 2 fail, 1 not testable; 11 insights |
| Tests with the data | python scripts/run_tests_with_evidence.py | 23 passed, 0 failed |
| Figures, dashboard, report, deck | scripts/make_figures.py, make_insight_figures.py, make_demo_dashboard.py, build_dashboard.py, build_report_docx.py, build_presentation.py | built without errors |
| Comparison with the main project | pandas equality of K_DQ_Report, SQL_Test_Cases, Insights, Relationship_Tests | identical (35, 38, 11 and 18 rows) |

Environment: Python 3.12, pandas, openpyxl, matplotlib, python-docx, python-pptx, pytest (requirements.txt). Input hashes and versions: outputs/run_manifest.json. Generated data uses fixed seed 2026.

Limits: reproducibility is shown on one machine type; dashboards were checked in a headless Chromium browser; nothing here validates a metric on production data.
