# How VELOOP Rewards can use these analytics once real production data exists

**Status of everything in this project: validated only on simulated or generated data. No KPI, dashboard or insight is production-ready.** The value of the project is the method, the checks and the code, which are re-run on governed production data. No simulated number should be carried into a business report.

## 1. Go-live sequence (do these in order)
| Step | Action | Gate to pass before moving on | Owner |
|---|---|---|---|
| 1 | Verify instrumentation: stable `user_id`, unique `transaction_id`, UTC timestamps, one shared id per task attempt (start and outcome), separate reward and wallet records | Backlog Critical items done; assumptions A001-A011 answered | Engineering |
| 2 | Take the first production extract into a separate folder (never `data/raw`); strip personal fields at ingestion | No names, emails or credentials present | Data + Engineering |
| 3 | Run `python run.py profile evidence`-style checks on the extract (same code) | No Critical issue open; orphan checks pass; duplicate rules reviewed | Data |
| 4 | Re-run the KPI validation (SQL vs independent calculation) against production tables | Every KPI you intend to report matches; reward-to-wallet reconciliation gap (K29) explained | Data + Product |
| 5 | Publish dashboards only for validated KPIs, labelled "validated on production data, date" | Sign-off recorded in the change log | Product |

## 2. Operating rhythm
- **Daily (Data, Operations):** data quality pass, reward-to-wallet reconciliation (K29), pending reward pool and age (K22), withdrawal queue and processing time (K32, K35).
- **Weekly (Product):** active users using complete weeks only plus active share of registered users (K05), task completion by type and device (K12), reward activity by feature (K23), rejection and reversal reasons (K33, K20).
- **Monthly (Product, Growth, Finance):** retention by acquisition source and cohort, referral funnel (K39-K42), withdrawal volume by method (K37, K38), KPI definition review through the change log.

## 3. Decision playbook (what to look at, who acts)
| Signal | Look at | Typical action | Owner |
|---|---|---|---|
| Completed tasks without a credited reward, or duplicate credits | K24, K29 | Reconcile ledger, fix the credit job, add a uniqueness rule | Engineering |
| Pending reward pool growing or ageing | K22 | Check the third-party validation path; define an expiry rule | Product + Engineering |
| Withdrawal queue age rising | K32, K35 | Review staffing and automation; check method-specific delays | Operations |
| Many rejections for one reason | K33 | Improve user guidance before the request is made | Product |
| Reversals rising for one source or feature | K20, K21 | Refer to the security team for review; this project sets no fraud thresholds | Security |
| Completion lower on one task type or device | K12, K11 | Test the client or provider integration for that segment | Engineering |
| Referral registrations without activation | K40, K41 | Review the activation rule and onboarding of referred users | Growth |
| Channel with many registrations but low return | K02, K04, cohort retention | Review channel quality, not just volume | Growth |

## 4. Targets and thresholds
Targets are set by Product and Finance after a baseline of several weeks of real data. This project defines KPIs, not targets, and no number from the simulation should be used as a benchmark.

## 5. What the simulated results taught us to check first on real data
1. **Event pairing:** every outcome event must share a task attempt id with its start. In the simulated events only 8.5% to 13.8% of finish events had an earlier start in the same session, so finish-over-start ratios were meaningless.
2. **Partial periods:** drop incomplete weeks and months from trends; show them separately.
3. **User-base growth:** a rising active-user count can simply follow a growing base; always add the active share of registered users.
4. **One user master:** two user tables with the same ids but different attributes made joins unsafe.
5. **Reward and credit are different facts:** keep a separate reward and ledger record so a gap can appear.

## 6. Governance and change
Only IDs and analytical attributes are used. Access follows the role model in the report. Any change to an event, field, reward rule, withdrawal method, KPI or dashboard goes through the change log, and a changed KPI becomes a new version.

## 7. Limits
These analytics describe behaviour and process health. They do not prove causes, detect fraud by themselves, or replace testing of product changes.
