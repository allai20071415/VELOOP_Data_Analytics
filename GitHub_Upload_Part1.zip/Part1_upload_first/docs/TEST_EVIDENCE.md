# Test evidence

Generated 2026-11-10 by `python scripts/run_tests_with_evidence.py` | Python 3.12.3 | Linux-6.18.44-fc-v338-x86_64-with-glibc2.39

**Result: 23 passed, 0 failed, 0 skipped, 23 total.**

Data-dependent tests need the two supplied workbooks in `data/raw/` and skip without them. All tests describe SIMULATED or GENERATED data; none validates production data.

Raw outputs: `outputs/test_log.txt` (pytest -v), `outputs/test_results.xml` (JUnit). Validation workbooks: `outputs/VELOOP_KPI_Validation.xlsx` (38 SQL test cases with SQL, both results, tolerance, pass flag; 6 reconciliations), `outputs/VELOOP_ER_Validation.xlsx`.

| Test file | Test case | What it proves | Result | Seconds |
|---|---|---|---|---|
| test_analytics | `test_ztest_known_values` | Two-proportion z-test returns p=1 for equal rates and p<0.001 for very different rates. | PASS | 0.00 |
| test_analytics | `test_kpi_spec_ids_are_unique_and_labelled` | All 46 KPIs have an SQL formula and one of the three availability labels. | PASS | 0.00 |
| test_analytics | `test_every_evidence_file_matches_reported_count` | 35 issues; 31 have evidence rows and each evidence row count equals the reported record count. | PASS | 12.93 |
| test_analytics | `test_generated_data_is_deterministic_labelled_and_unflattering` | Generated tables are identical across runs (seed), carry the SIMULATED label, and include failures and duplicates. | PASS | 0.72 |
| test_analytics | `test_kpi_review_covers_all_46_and_runs_on_both_data_sets` | KPI review has 46 unique rows; calculable KPIs have values; not-calculable KPIs never carry an invented supplied value. | PASS | 0.46 |
| test_analytics | `test_insights_are_computed_and_free_of_nan` | 11 insights are computed and none contains NaN text. | PASS | 0.19 |
| test_quality | `test_known_messy_user_issues` | test known messy user issues | PASS | 12.57 |
| test_quality | `test_event_audit_issues` | test event audit issues | PASS | 0.14 |
| test_quality | `test_no_orphans` | test no orphans | PASS | 0.05 |
| test_quality | `test_cross_file_conflict_found` | test cross file conflict found | PASS | 0.00 |
| test_quality | `test_user_cleaning` | test user cleaning | PASS | 0.00 |
| test_quality | `test_event_cleaning` | test event cleaning | PASS | 0.07 |
| test_unit | `test_user_cleaning_dedupes_and_quarantines` | test user cleaning dedupes and quarantines | PASS | 0.00 |
| test_unit | `test_event_cleaning_normalises_and_dedupes` | test event cleaning normalises and dedupes | PASS | 0.00 |
| test_unit | `test_fk_detects_orphans` | test fk detects orphans | PASS | 0.00 |
| test_unit | `test_fk_passes_when_clean` | test fk passes when clean | PASS | 0.00 |
| test_unit | `test_profile_counts_duplicates_and_missing` | test profile counts duplicates and missing | PASS | 0.00 |
| test_validation | `test_sql_formulas_equal_independent_pandas_results` | All 38 SQL test cases give the same number as an independent pandas calculation (supplied and generated data). | PASS | 14.46 |
| test_validation | `test_every_kpi_has_a_validation_status_and_none_is_production_ready` | 46 KPIs each carry a validation status; none is marked production-ready; no validation failed. | PASS | 1.65 |
| test_validation | `test_er_relationships_have_expected_results` | Supplied-data relationships pass; tasks catalogue and duplicate credits fail; support tickets are not testable. | PASS | 0.04 |
| test_validation | `test_event_ratio_investigation_event_ids_unique_and_pairing_low` | Ratios above 1 are not a duplicate artefact (event_id unique, still >1 after dedup) and fewer than 20% of finishes have an earlier start in-session. | PASS | 0.23 |
| test_validation | `test_partial_weeks_are_flagged` | First week covers 5 days and last week 2 days of the period; both are flagged partial; all other weeks are complete. | PASS | 0.20 |
| test_validation | `test_dashboard_is_labelled_aggregate_only_and_marks_partial_weeks` | The functional dashboard carries the SIMULATED banner, marks partial weeks, and embeds no email addresses or names. | PASS | 0.02 |
