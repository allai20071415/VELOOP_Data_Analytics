"""Executable validation of KPI formulas. Each case runs a SQL formula (SQLite) and an independent pandas calculation and compares them.
Cases on SUPPLIED data validate the formula on the simulated test files; cases on GENERATED data only prove the formula runs (data/synthetic).
NOTHING here validates a KPI on production data: every KPI is 'not production-ready' until it is re-run on governed production data."""
import re, sqlite3
import numpy as np, pandas as pd
from .config import PERIOD_END

END = "2026-09-16"            # exclusive end of period (15 Sep 2026 inclusive)
def _tables(d, g):
    con = sqlite3.connect(":memory:")
    num = {"amount", "requested_amount", "final_amount"}
    src = {"users_a": d["A:Users_1000_Clean"], "users_b": d["B:01_Users_1000"], "sessions": d["B:02_Sessions"], "events": d["B:03_Feature_Events"], "tasks": d["B:05_Task_Activity"], **g}
    for n, df in src.items():
        df = df.copy()
        for c in df.columns:
            if c in num: df[c] = pd.to_numeric(df[c])
        df.to_sql(n, con, index=False)
    return con

# (id, kpi, kind, sql, pandas function (d, g) -> value, tolerance)
def cases():
    ts = lambda s: pd.to_datetime(s)
    C = []
    def add(i, k, kind, sql, fn, tol=0.0): C.append((i, k, kind, sql, fn, tol))
    A = lambda d: d["A:Users_1000_Clean"]; E = lambda d: d["B:03_Feature_Events"]; T = lambda d: d["B:05_Task_Activity"]
    add("V01", "K01", "supplied", f"SELECT COUNT(DISTINCT user_id) FROM users_a WHERE registration_datetime >= '2026-04-01' AND registration_datetime < '{END}'", lambda d, g: A(d)[(ts(A(d).registration_datetime) >= "2026-04-01") & (ts(A(d).registration_datetime) < END)].user_id.nunique())
    add("V02", "K03", "supplied", "SELECT COUNT(DISTINCT user_id) FROM events WHERE substr(event_datetime,1,10) = '2026-09-10'", lambda d, g: E(d)[E(d).event_datetime.str[:10] == "2026-09-10"].user_id.nunique())
    add("V03", "K04", "supplied", "SELECT COUNT(DISTINCT e.user_id) FROM events e JOIN users_b u ON u.user_id = e.user_id WHERE e.event_datetime >= '2026-08-16' AND u.registration_datetime < '2026-08-16'",
        lambda d, g: E(d)[ts(E(d).event_datetime) >= "2026-08-16"].merge(d["B:01_Users_1000"], on="user_id").pipe(lambda x: x[ts(x.registration_datetime) < "2026-08-16"].user_id.nunique()))
    add("V04", "K05", "supplied", "SELECT COUNT(DISTINCT user_id) FROM events WHERE event_datetime >= '2026-08-01' AND event_datetime < '2026-09-01'", lambda d, g: E(d)[(ts(E(d).event_datetime) >= "2026-08-01") & (ts(E(d).event_datetime) < "2026-09-01")].user_id.nunique())
    add("V05", "K06", "supplied", "SELECT 1.0*SUM(onboarding_status='Completed')/COUNT(*) FROM users_a", lambda d, g: (A(d).onboarding_status == "Completed").mean(), 1e-12)
    add("V06", "K07", "supplied", "SELECT COUNT(*) FROM users_a WHERE last_login_datetime IS NULL OR last_login_datetime < '2026-08-16'", lambda d, g: int((A(d).last_login_datetime.isna() | (ts(A(d).last_login_datetime) < "2026-08-16")).sum()))
    add("V07", "K10", "supplied", "SELECT COUNT(*) FROM users_a WHERE account_status = 'Active'", lambda d, g: int((A(d).account_status == "Active").sum()))
    add("V08", "K11", "supplied", "SELECT COUNT(activity_id) FROM tasks WHERE task_started_at IS NOT NULL", lambda d, g: int(T(d).task_started_at.notna().sum()))
    add("V09", "K12", "supplied", "SELECT 1.0*SUM(task_status='Completed')/COUNT(*) FROM tasks WHERE task_started_at IS NOT NULL", lambda d, g: (T(d)[T(d).task_started_at.notna()].task_status == "Completed").mean(), 1e-12)
    add("V10", "K13", "supplied", "SELECT COUNT(*) FROM tasks WHERE task_status = 'Completed'", lambda d, g: int((T(d).task_status == "Completed").sum()))
    add("V11", "K14", "supplied", "SELECT 1.0*SUM(failure_reason='Timeout' AND task_status IN ('Failed','Abandoned'))/COUNT(*) FROM tasks", lambda d, g: ((T(d).failure_reason == "Timeout") & T(d).task_status.isin(["Failed", "Abandoned"])).mean(), 1e-12)
    add("V12", "K15", "supplied", "SELECT COUNT(DISTINCT user_id) FROM events WHERE feature_name = 'Watch Ads'", lambda d, g: E(d)[E(d).feature_name == "Watch Ads"].user_id.nunique())
    add("V13", "K16", "supplied", "SELECT 1.0*SUM(n>=2)/COUNT(*) FROM (SELECT user_id, COUNT(DISTINCT substr(event_datetime,1,10)) n FROM events GROUP BY user_id)", lambda d, g: (E(d).assign(day=E(d).event_datetime.str[:10]).groupby("user_id").day.nunique() >= 2).mean(), 1e-12)
    add("V14", "K17", "supplied", "SELECT 1.0*COUNT(DISTINCT CASE WHEN feature_name='Badges' THEN user_id END)/COUNT(DISTINCT user_id) FROM events", lambda d, g: E(d)[E(d).feature_name == "Badges"].user_id.nunique() / E(d).user_id.nunique(), 1e-12)
    add("V15", "K22", "supplied", "SELECT COUNT(*) FROM tasks WHERE reward_status = 'Pending'", lambda d, g: int((T(d).reward_status == "Pending").sum()))
    add("V16", "K24", "supplied", "SELECT 1.0*SUM(reward_status='Credited')/COUNT(*) FROM tasks WHERE task_status='Completed'", lambda d, g: (T(d)[T(d).task_status == "Completed"].reward_status == "Credited").mean(), 1e-12)
    R = lambda g: g["rewards"]; W = lambda g: g["wallet"].drop_duplicates("transaction_id"); D = lambda g: g["withdrawals"]; F = lambda g: g["referrals"]
    add("V17", "K18", "generated", "SELECT COUNT(*) FROM rewards", lambda d, g: len(R(g)))
    add("V18", "K19", "generated", "SELECT SUM(amount) FROM rewards WHERE status='credited' AND unit='VE'", lambda d, g: R(g)[(R(g).status == "credited") & (R(g).unit == "VE")].amount.sum(), 1e-6)
    add("V19", "K20", "generated", "SELECT COUNT(*) FROM rewards WHERE status='reversed'", lambda d, g: int((R(g).status == "reversed").sum()))
    add("V20", "K21", "generated", "SELECT 1.0*SUM(status='reversed')/SUM(status='credited') FROM rewards", lambda d, g: (R(g).status == "reversed").sum() / (R(g).status == "credited").sum(), 1e-12)
    add("V21", "K25", "generated", "SELECT COUNT(DISTINCT transaction_id) FROM wallet", lambda d, g: len(W(g)))
    add("V22", "K26", "generated", "SELECT SUM(amount) FROM (SELECT DISTINCT transaction_id, amount, direction, status, unit FROM wallet) WHERE direction='credit' AND status='completed' AND unit='VE'", lambda d, g: W(g)[(W(g).direction == "credit") & (W(g).status == "completed") & (W(g).unit == "VE")].amount.sum(), 1e-6)
    add("V23", "K27", "generated", "SELECT COUNT(*) FROM (SELECT DISTINCT transaction_id, transaction_type, status FROM wallet) WHERE transaction_type IN ('redemption','exchange') AND status='completed'", lambda d, g: int((W(g).transaction_type.isin(["redemption", "exchange"]) & (W(g).status == "completed")).sum()))
    add("V24", "K28", "generated", "SELECT 1.0*SUM(transaction_type='reversal')/COUNT(*) FROM (SELECT DISTINCT transaction_id, transaction_type FROM wallet)", lambda d, g: (W(g).transaction_type == "reversal").mean(), 1e-12)
    add("V25", "K29", "generated", "SELECT COUNT(*) FROM rewards r WHERE r.status='credited' AND NOT EXISTS (SELECT 1 FROM wallet w WHERE w.reference_id = r.reward_id AND w.status='completed')",
        lambda d, g: int((~R(g)[R(g).status == "credited"].reward_id.isin(set(g["wallet"][g["wallet"].status == "completed"].reference_id))).sum()))
    add("V26", "K30", "generated", "SELECT COUNT(withdrawal_id) FROM withdrawals", lambda d, g: len(D(g)))
    add("V27", "K31", "generated", "SELECT COUNT(*) FROM withdrawals WHERE status='completed'", lambda d, g: int((D(g).status == "completed").sum()))
    add("V28", "K32", "generated", "SELECT COUNT(*) FROM withdrawals WHERE status IN ('requested','processing')", lambda d, g: int(D(g).status.isin(["requested", "processing"]).sum()))
    add("V29", "K33", "generated", "SELECT COUNT(*) FROM withdrawals WHERE status='rejected' AND reason_category='incomplete_request'", lambda d, g: int(((D(g).status == "rejected") & (D(g).reason_category == "incomplete_request")).sum()))
    add("V30", "K34", "generated", "SELECT COUNT(*) FROM withdrawals WHERE status='reversed'", lambda d, g: int((D(g).status == "reversed").sum()))
    add("V31", "K35", "generated", "SELECT AVG(x) FROM (SELECT julianday(finalized_at)-julianday(requested_at) AS x FROM withdrawals WHERE status='completed' ORDER BY x LIMIT 2 - (SELECT COUNT(*) FROM withdrawals WHERE status='completed') % 2 OFFSET (SELECT (COUNT(*)-1)/2 FROM withdrawals WHERE status='completed'))",
        lambda d, g: ((ts(D(g)[D(g).status == "completed"].finalized_at) - ts(D(g)[D(g).status == "completed"].requested_at)).dt.total_seconds() / 86400).median(), 1e-6)
    add("V32", "K36", "generated", "SELECT 1.0*SUM(status='completed')/SUM(status IN ('completed','rejected','reversed')) FROM withdrawals WHERE requested_at < '2026-09-02'",
        lambda d, g: (lambda o: (o[o.status.isin(["completed", "rejected", "reversed"])].status == "completed").mean())(D(g)[ts(D(g).requested_at) < "2026-09-02"]), 1e-12)
    add("V33", "K37", "generated", "SELECT SUM(final_amount) FROM withdrawals WHERE status='completed'", lambda d, g: D(g)[D(g).status == "completed"].final_amount.sum(), 1e-6)
    add("V34", "K38", "generated", "SELECT 1.0*SUM(method='method_A')/COUNT(*) FROM withdrawals", lambda d, g: (D(g).method == "method_A").mean(), 1e-12)
    add("V35", "K39", "generated", "SELECT COUNT(DISTINCT referral_id) FROM referrals", lambda d, g: F(g).referral_id.nunique())
    add("V36", "K40", "generated", "SELECT COUNT(*) FROM referrals WHERE registered_at IS NOT NULL", lambda d, g: int(F(g).registered_at.notna().sum()))
    add("V37", "K41", "generated", "SELECT COUNT(*) FROM referrals WHERE activated_at IS NOT NULL", lambda d, g: int(F(g).activated_at.notna().sum()))
    add("V38", "K42", "generated", "SELECT 1.0*SUM(status='converted')/COUNT(*) FROM referrals WHERE created_at < '2026-08-17'", lambda d, g: (F(g)[ts(F(g).created_at) < "2026-08-17"].status == "converted").mean(), 1e-12)
    return C

def reconciliations(d, g, kpi_df):
    """Alternate-method checks for KPIs that are not a single SQL scalar. Returns (id, kpi, description, expected, actual, passed)."""
    out = []; A = d["A:Users_1000_Clean"]; E = d["B:03_Feature_Events"]; T = d["B:05_Task_Activity"]; U = d["B:01_Users_1000"]
    out.append(("R01", "K02", "registrations by source add up to total registrations", len(A), int(A.acquisition_source.value_counts().sum()), len(A) == A.acquisition_source.value_counts().sum()))
    out.append(("R02", "K10", "account status distribution adds up to all users", len(A), int(A.account_status.value_counts().sum()), len(A) == A.account_status.value_counts().sum()))
    out.append(("R03", "K23", "credited-task counts by category add up to all Credited tasks", int((T.reward_status == "Credited").sum()), int(T[T.reward_status == "Credited"].task_category.value_counts().sum()), True))
    Ev = E.assign(day=E.event_datetime.str[:10], mon=E.event_datetime.str[:7]); aug = Ev[Ev.mon == "2026-08"]
    a = aug.groupby("day").user_id.nunique().mean() / aug.user_id.nunique(); b = (pd.crosstab(aug.day, aug.user_id) > 0).sum(axis=1).mean() / (pd.crosstab(aug.day, aug.user_id) > 0).any().sum()
    out.append(("R04", "K08", "stickiness via groupby equals stickiness via crosstab", round(float(a), 9), round(float(b), 9), abs(a - b) < 1e-9))
    reg = pd.to_datetime(U.set_index("user_id").registration_datetime); f1 = E.assign(ts=pd.to_datetime(E.event_datetime)).groupby("user_id").ts.min()
    f2 = E.assign(ts=pd.to_datetime(E.event_datetime)).sort_values("ts").drop_duplicates("user_id").set_index("user_id").ts
    m1 = ((f1 - reg.reindex(f1.index)).dt.total_seconds() / 3600).pipe(lambda x: x[x >= 0]).median(); m2 = ((f2.reindex(f1.index) - reg.reindex(f1.index)).dt.total_seconds() / 3600).pipe(lambda x: x[x >= 0]).median()
    out.append(("R05", "K09", "median time to first event via min() equals via sort + drop_duplicates", round(float(m1), 6), round(float(m2), 6), abs(m1 - m2) < 1e-6))
    um = d["A:Users_Messy_Audit"]; req = ["registration_datetime", "acquisition_source", "primary_device", "email_verification_status", "onboarding_status", "age", "gender", "city"]; clean = A.set_index("user_id")
    seen = set(); bad = 0
    for _, r in um.iterrows():   # row-wise loop, independent of the vectorised K46 code
        flag = r.user_id in seen; seen.add(r.user_id)
        flag |= any(pd.isna(r[c]) for c in req) or pd.isna(pd.to_datetime(r.registration_datetime, errors="coerce"))
        if r.user_id in clean.index and pd.notna(r.registration_datetime) and pd.notna(pd.to_datetime(r.registration_datetime, errors="coerce")) and r.registration_datetime != clean.loc[r.user_id, "registration_datetime"]: flag = True
        if pd.isna(r.last_login_datetime) and r.account_status != "Pending Verification": flag = True
        bad += bool(flag)
    v = kpi_df.loc[kpi_df.kpi_id == "K46", "value_on_supplied_simulated_data"].iloc[0]; n_pass = int(re.search(r"Users_Messy_Audit: ([\d,]+) of", v).group(1).replace(",", ""))
    out.append(("R06", "K46", "rows passing all hard rules: row-by-row loop equals the vectorised KPI value", len(um) - bad, n_pass, len(um) - bad == n_pass))
    return out

def run(d, g, kpi_df):
    con = _tables(d, g); rows = []
    for cid, kpi, kind, sql, fn, tol in cases():
        s = con.execute(sql).fetchone()[0]; p = fn(d, g); s = float(s); p = float(p)
        rows.append({"case_id": cid, "kpi_id": kpi, "dataset": kind, "sql": sql, "sql_result": s, "pandas_result": p, "tolerance": tol, "passed": bool(abs(s - p) <= tol + 1e-12)})
    rec = pd.DataFrame([dict(zip(["case_id", "kpi_id", "check", "expected", "actual", "passed"], r)) for r in reconciliations(d, g, kpi_df)])
    return pd.DataFrame(rows), rec

def summary(kpi_df, cases_df, rec_df):
    """One row per KPI: formula, source fields, limitation, validation evidence and status."""
    from .kpi_engine import AV_OK, AV_PART, AV_NO
    cat = {r.kpi_id: r for r in kpi_df.itertuples()}; out = []
    for k, r in cat.items():
        cs = cases_df[cases_df.kpi_id == k]; rc = rec_df[rec_df.kpi_id == k]
        sup = cs[cs.dataset == "supplied"]; gen = cs[cs.dataset == "generated"]
        if len(sup) and sup.passed.all(): status, method = "Validated on supplied simulated data", f"SQL equals independent pandas result ({', '.join(sup.case_id)})"
        elif len(rc) and rc.passed.all(): status, method = "Validated on supplied simulated data", f"Alternate-method reconciliation ({', '.join(rc.case_id)})"
        elif len(gen) and gen.passed.all(): status, method = "Formula tested on generated test data only", f"SQL equals independent pandas result on generated tables ({', '.join(gen.case_id)})"
        elif r.availability == AV_PART: status, method = "Proxy only: KPI itself not validated", "Only a proxy count exists in the supplied data; no formula validation"
        else: status, method = "Not validated: data not supplied", "No supplied or generated data supports this KPI"
        if len(cs) and not cs.passed.all() or len(rc) and not rc.passed.all(): status = "VALIDATION FAILED"
        if r.availability == AV_PART and "Validated" in status: status += " (proxy value)"
        out.append({"kpi_id": k, "kpi_name": r.kpi_name, "exact_sql_formula": r.exact_sql_formula, "source_fields_required": r.required_fields, "supplied_columns_mapped_or_missing": r.mapped_or_missing_in_supplied_data,
                    "limitation": r.limitation, "availability": r.availability, "validation_status": status, "validation_method": method,
                    "production_ready": "No. Validated only on simulated or generated data; re-run on governed production data before relying on it"})
    return pd.DataFrame(out)
