"""Generate the four tables that were NOT supplied (Rewards, Wallet, Withdrawals, Referrals) so the KPI code can be tested.

Every row is labelled SIMULATED DATA - CREATED FOR ANALYTICAL TESTING. The output is for exercising formulas only and
supports NO business insight. It is derived from the supplied behaviour workbook (tasks, users) with fixed seed 2026, and it
deliberately contains unfavourable outcomes (rejected, pending, reversed, duplicate rows). Methodology: data/synthetic/METHODOLOGY.md
Invented parts are marked PROPOSED in the methodology (unit mix, payout method names, activation rule)."""
import numpy as np, pandas as pd
from .config import ROOT, PERIOD_END
LABEL = "SIMULATED DATA - CREATED FOR ANALYTICAL TESTING"
OUT = ROOT / "data" / "synthetic"
BASE = {"Advertisement": 5, "Survey": 40, "CAPTCHA": 2, "Social Activity": 10, "Game": 15, "Mission": 25, "App Task": 30, "Promotional Task": 20}
SEED = 2026

def generate(d):
    rng = np.random.default_rng(SEED); T, U, E = d["B:05_Task_Activity"], d["B:01_Users_1000"], d["B:03_Feature_Events"]
    end = PERIOD_END + pd.Timedelta(days=1)
    # ---------- rewards ----------
    t = T[T.reward_status.isin(["Credited", "Pending"])].copy()
    t["base"] = t.task_category.map(BASE); t["amount"] = (t.base * rng.choice([0.5, 1, 1.5, 2], len(t))).round(1)
    t["unit"] = rng.choice(["VE", "XP", "Gems"], len(t), p=[0.85, 0.10, 0.05])
    anchor = pd.to_datetime(t.task_completed_at.fillna(t.task_started_at))
    t["created_at"] = anchor + pd.to_timedelta(rng.integers(1, 30, len(t)), unit="s")
    rw = pd.DataFrame({"reward_id": [f"RW{i:06d}" for i in range(1, len(t) + 1)], "user_id": t.user_id.values, "source_activity_id": t.activity_id.values,
                       "reward_source_type": "task", "amount": t.amount.values, "unit": t.unit.values,
                       "status": np.where(t.reward_status == "Credited", "credited", "pending"), "created_at": t.created_at.values})
    rw["credited_at"] = np.where(rw.status == "credited", rw.created_at, pd.NaT); rw["original_reward_id"] = None; rw["reason_category"] = None
    cred = rw[rw.status == "credited"]
    rev = cred.sample(frac=0.025, random_state=SEED).copy(); rev["original_reward_id"] = rev.reward_id; rev["reward_id"] = [f"RW{i:06d}" for i in range(len(rw) + 1, len(rw) + 1 + len(rev))]
    rev["status"] = "reversed"; rev["reason_category"] = rng.choice(["duplicate", "invalid_activity", "provider_chargeback", "other"], len(rev), p=[.2, .4, .25, .15])
    rev["created_at"] = pd.to_datetime(rev.created_at) + pd.to_timedelta(rng.integers(1, 10, len(rev)), unit="D"); rev = rev[rev.created_at < end]; rev["credited_at"] = pd.NaT
    n0 = len(rw) + len(rev)
    cor = cred.drop(rev.original_reward_id.values, errors="ignore").sample(frac=0.008, random_state=SEED + 1).copy(); cor["original_reward_id"] = cor.reward_id
    cor["reward_id"] = [f"RW{i:06d}" for i in range(n0 + 1, n0 + 1 + len(cor))]; cor["status"] = "corrected"; cor["amount"] = (cor.amount * rng.choice([-0.5, 0.5], len(cor))).round(1)
    cor["reason_category"] = "manual_correction"; cor["credited_at"] = pd.NaT
    dup = cred.sample(n=15, random_state=SEED + 2).copy(); dup["reward_id"] = [f"RW{i:06d}" for i in range(n0 + len(cor) + 1, n0 + len(cor) + 16)]   # same source_activity credited twice
    rewards = pd.concat([rw, rev, cor, dup], ignore_index=True)
    rewards.loc[len(rw):, "reward_id"] = [f"RW{i:06d}" for i in range(len(rw) + 1, len(rewards) + 1)]   # unique ids for reversal/correction/duplicate rows
    # ---------- wallet ----------
    w = rewards[rewards.status.isin(["credited", "reversed", "corrected"])].copy()
    ttype = {"credited": "reward_credit", "reversed": "reversal", "corrected": "adjustment"}
    w["transaction_type"] = w.status.map(ttype); w["direction"] = np.where(w.status == "reversed", "debit", np.where((w.status == "corrected") & (w.amount < 0), "debit", "credit"))
    w["amount_abs"] = w.amount.abs(); u = rng.random(len(w))
    w["wstatus"] = np.where(u < 0.015, "pending", np.where(u < 0.025, "failed", "completed"))
    wallet = pd.DataFrame({"transaction_id": [f"WT{i:06d}" for i in range(1, len(w) + 1)], "user_id": w.user_id.values, "created_at": w.created_at.values,
                           "transaction_type": w.transaction_type.values, "direction": w.direction.values, "amount": w.amount_abs.values, "unit": w.unit.values,
                           "status": w.wstatus.values, "source": "rewards", "reference_id": w.reward_id.values})
    ref2tx = dict(zip(wallet.reference_id, wallet.transaction_id)); orig_of = dict(zip(rewards.reward_id, rewards.original_reward_id))
    wallet["related_transaction_id"] = [ref2tx.get(orig_of.get(r)) if orig_of.get(r) is not None and pd.notna(orig_of.get(r)) else None for r in wallet.reference_id]
    # redemptions
    ru = rng.choice(U.user_id.values, int(0.06 * len(U)), replace=False); rows = []
    for uid in ru:
        for _ in range(rng.integers(1, 5)):
            rows.append((uid, pd.Timestamp("2026-04-01") + pd.to_timedelta(int(rng.integers(0, 167 * 24 * 3600)), unit="s"), float(rng.choice([10, 25, 50, 100, 200]))))
    k = len(wallet); red = pd.DataFrame(rows, columns=["user_id", "created_at", "amount"])
    red = red.assign(transaction_id=[f"WT{i:06d}" for i in range(k + 1, k + 1 + len(red))], transaction_type="redemption", direction="debit", unit="VE", status="completed", source="exchange", reference_id=None, related_transaction_id=None)
    # ---------- withdrawals ----------
    ve = rewards[(rewards.status == "credited") & (rewards.unit == "VE")].groupby("user_id").amount.sum()
    cand = ve[ve > 0]; pw = (cand / cand.sum()).values
    wd_users = rng.choice(cand.index.values, 1500, p=pw)
    first = pd.to_datetime(rewards[rewards.status == "credited"].groupby("user_id").created_at.min())
    req = [first[u] + pd.to_timedelta(int(rng.integers(3600, 60 * 24 * 3600)), unit="s") for u in wd_users]
    wd = pd.DataFrame({"withdrawal_id": [f"WD{i:05d}" for i in range(1, 1501)], "user_id": wd_users, "requested_at": req})
    wd = wd[wd.requested_at < end].head(1200).reset_index(drop=True)
    wd["requested_amount"] = rng.choice([50, 100, 200, 500], len(wd), p=[.4, .3, .2, .1]).astype(float); wd["unit"] = "VE"
    wd["method"] = rng.choice(["method_A", "method_B", "method_C"], len(wd), p=[.5, .3, .2])
    proc = wd.requested_at + pd.to_timedelta(rng.exponential(6 * 3600, len(wd)), unit="s")
    fin = proc + pd.to_timedelta(rng.lognormal(np.log(1.5), 0.9, len(wd)), unit="D")
    outcome = rng.choice(["completed", "rejected", "reversed", "stuck"], len(wd), p=[.63, .14, .03, .20])
    status, ps, fs, reason, famt = [], [], [], [], []
    for i in range(len(wd)):
        o = outcome[i]; p_, f_ = proc.iloc[i], fin.iloc[i]
        if p_ >= end: status.append("requested"); ps.append(pd.NaT); fs.append(pd.NaT); reason.append(None); famt.append(np.nan); continue
        if o == "stuck" or f_ >= end: status.append("processing"); ps.append(p_); fs.append(pd.NaT); reason.append(None); famt.append(np.nan); continue
        status.append(o); ps.append(p_); fs.append(f_); famt.append(wd.requested_amount.iloc[i] if o in ("completed", "reversed") else np.nan)
        reason.append(rng.choice(["incomplete_request", "verification_required", "limit_exceeded", "other"]) if o == "rejected" else (rng.choice(["payout_failed", "duplicate", "other"]) if o == "reversed" else None))
    wd["processing_started_at"], wd["finalized_at"], wd["status"], wd["reason_category"], wd["final_amount"] = ps, fs, status, reason, famt
    # wallet debit for non-rejected requests
    k2 = len(wallet) + len(red); deb = wd[wd.status.isin(["processing", "completed", "reversed"])]
    wdeb = pd.DataFrame({"transaction_id": [f"WT{i:06d}" for i in range(k2 + 1, k2 + 1 + len(deb))], "user_id": deb.user_id.values, "created_at": deb.requested_at.values, "transaction_type": "withdrawal",
                         "direction": "debit", "amount": deb.requested_amount.values, "unit": "VE", "status": np.where(deb.status == "reversed", "reversed", "completed"), "source": "withdrawals", "reference_id": deb.withdrawal_id.values, "related_transaction_id": None})
    wd["wallet_transaction_id"] = wd.withdrawal_id.map(dict(zip(wdeb.reference_id, wdeb.transaction_id)))
    wallet = pd.concat([wallet, red, wdeb], ignore_index=True)
    wallet = pd.concat([wallet, wallet.sample(n=12, random_state=SEED + 3)], ignore_index=True)     # 12 duplicate transaction rows
    # ---------- referrals (activation rule R1 is PROPOSED for testing) ----------
    ref_users = U[U.acquisition_source == "Referral"][["user_id", "registration_datetime"]].copy(); ref_users["registration_datetime"] = pd.to_datetime(ref_users.registration_datetime)
    comp = T[T.task_status == "Completed"].assign(ts=lambda x: pd.to_datetime(x.task_completed_at)); rows = []
    for _, r in ref_users.iterrows():
        c = comp[comp.user_id == r.user_id].sort_values("ts"); reg = r.registration_datetime
        within7 = c[(c.ts >= reg) & (c.ts <= reg + pd.Timedelta(days=7))]; within14 = c[(c.ts >= reg) & (c.ts <= reg + pd.Timedelta(days=14))]
        act = within7.ts.min() if len(within7) else pd.NaT; conv = len(within14) >= 3
        rows.append((r.user_id, reg, act, "converted" if conv and pd.notna(act) else ("activated" if pd.notna(act) else "registered")))
    rf = pd.DataFrame(rows, columns=["referred_user_id", "registered_at", "activated_at", "status"])
    code_users = U[U.referral_code.notna()].user_id.values
    rf["referrer_user_id"] = rng.choice(code_users, len(rf)); rf["created_at"] = rf.registered_at - pd.to_timedelta(rng.integers(1, 15, len(rf)), unit="D")
    extra = 900 - len(rf); ex = pd.DataFrame({"referrer_user_id": rng.choice(code_users, extra), "referred_user_id": None, "registered_at": pd.NaT, "activated_at": pd.NaT, "status": "created",
                                              "created_at": pd.Timestamp("2026-04-01") + pd.to_timedelta(rng.integers(0, 167 * 24 * 3600, extra), unit="s")})
    referrals = pd.concat([rf, ex], ignore_index=True); referrals.insert(0, "referral_id", [f"RF{i:05d}" for i in range(1, len(referrals) + 1)])
    referrals["referral_channel"] = rng.choice(["link", "code"], len(referrals)); referrals["activation_rule_id"] = np.where(referrals.activated_at.notna(), "R1_proposed", None)
    out = {"rewards": rewards, "wallet": wallet, "withdrawals": wd, "referrals": referrals}
    for k_, df in out.items(): df.insert(0, "data_label", LABEL)
    return out

def write(d):
    OUT.mkdir(parents=True, exist_ok=True); tabs = generate(d)
    for k, df in tabs.items(): df.to_csv(OUT / f"{k}.csv", index=False)
    return {k: len(v) for k, v in tabs.items()}
