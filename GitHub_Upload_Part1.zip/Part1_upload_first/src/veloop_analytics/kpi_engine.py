"""KPI review and calculation. For every one of the 46 catalogue KPIs: exact SQL formula, required and mapped fields, availability status,
value on the SUPPLIED simulated data (where it can be calculated) and value on GENERATED test data (formula test only).
Qualifying activity for active-user KPIs (proposed): any row in Feature_Events."""
import numpy as np, pandas as pd
from .config import PERIOD_END, ROOT

AV_OK, AV_PART, AV_NO = "Calculable (supplied data)", "Partial / proxy only (supplied data)", "Not calculable (data not supplied)"
# id: (exact SQL, mapped supplied columns or what is missing, availability)
SPEC = {
 "K01": ("SELECT COUNT(DISTINCT user_id) FROM users WHERE registration_datetime >= :start AND registration_datetime < :end", "A.Users_1000_Clean.user_id, registration_datetime", AV_OK),
 "K02": ("SELECT acquisition_source, COUNT(DISTINCT user_id) FROM users WHERE registration_datetime IN period GROUP BY 1", "A.Users.acquisition_source", AV_OK),
 "K03": ("SELECT COUNT(DISTINCT user_id) FROM feature_events WHERE CAST(event_datetime AS DATE) = :day", "B.Feature_Events.user_id, event_datetime", AV_OK),
 "K04": ("SELECT COUNT(DISTINCT e.user_id) FROM feature_events e JOIN users u USING(user_id) WHERE e.event_datetime IN window AND u.registration_datetime < :window_start", "B.Feature_Events + B.Users.registration_datetime", AV_OK),
 "K05": ("SELECT COUNT(DISTINCT user_id) FROM feature_events WHERE event_datetime >= :t0 AND event_datetime < :t0 + INTERVAL '30 day'", "B.Feature_Events.user_id", AV_OK),
 "K06": ("SELECT SUM(onboarding_status='Completed')::float / COUNT(*) FROM users", "A.Users.onboarding_status (snapshot; no onboarding events or timestamps)", AV_PART),
 "K07": ("SELECT COUNT(*) FROM users WHERE account_status <> 'closed' AND (last_login_datetime IS NULL OR last_login_datetime < :asof - INTERVAL '30 day')", "A.Users.last_login_datetime", AV_OK),
 "K08": ("SELECT AVG(dau) / mau FROM daily_active_users, monthly_active WHERE month = :m", "B.Feature_Events", AV_OK),
 "K09": ("SELECT PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY first_event_at - registered_at) FROM user_first_event JOIN users USING(user_id) WHERE first_event_at >= registered_at", "B.Users.registration_datetime + B.Feature_Events", AV_OK),
 "K10": ("SELECT account_status, COUNT(*) FROM users GROUP BY 1", "A.Users.account_status", AV_OK),
 "K11": ("SELECT COUNT(activity_id) FROM task_activity WHERE task_started_at IN period", "B.Task_Activity.task_started_at", AV_OK),
 "K12": ("SELECT SUM(task_status='Completed')::float / COUNT(*) FROM task_activity WHERE task_started_at IN period", "B.Task_Activity.task_status (no validation_status)", AV_OK),
 "K13": ("SELECT COUNT(*) FROM task_activity WHERE task_status='Completed'", "B.Task_Activity.task_status", AV_OK),
 "K14": ("SELECT failure_reason, COUNT(*)::float / (SELECT COUNT(*) FROM task_activity) FROM task_activity WHERE task_status IN ('Failed','Abandoned') GROUP BY 1", "B.Task_Activity.failure_reason (contradicts status in some rows, see DQ)", AV_PART),
 "K15": ("SELECT feature_name, COUNT(DISTINCT user_id) FROM feature_events GROUP BY 1", "B.Feature_Events.feature_name", AV_OK),
 "K16": ("SELECT COUNT(*) FILTER (WHERE active_days >= 2)::float / COUNT(*) FROM (SELECT user_id, COUNT(DISTINCT CAST(event_datetime AS DATE)) active_days FROM feature_events GROUP BY 1) t", "B.Feature_Events", AV_OK),
 "K17": ("SELECT feature_name, COUNT(DISTINCT user_id)::float / (SELECT COUNT(DISTINCT user_id) FROM feature_events) FROM feature_events GROUP BY 1", "B.Feature_Events", AV_OK),
 "K18": ("SELECT COUNT(reward_id) FROM rewards WHERE created_at IN period", "Missing: reward records. Proxy: Task_Activity.reward_status='Credited'", AV_PART),
 "K19": ("SELECT unit, SUM(amount) FROM rewards WHERE status='credited' GROUP BY unit", "Missing: reward amount and unit (no column exists)", AV_NO),
 "K20": ("SELECT COUNT(*), SUM(amount) FROM rewards WHERE status='reversed'", "Missing: reversal state", AV_NO),
 "K21": ("SELECT COUNT(*) FILTER (WHERE status='reversed')::float / NULLIF(COUNT(*) FILTER (WHERE status='credited'),0) FROM rewards", "Missing: reversal state", AV_NO),
 "K22": ("SELECT COUNT(*), AVG(now - created_at) FROM rewards WHERE status='pending'", "Task_Activity.reward_status='Pending' (count only; no age)", AV_PART),
 "K23": ("SELECT reward_source_type, unit, SUM(amount) FROM rewards WHERE status='credited' GROUP BY 1,2", "Proxy: credited task count by task_category", AV_PART),
 "K24": ("SELECT COUNT(*) FILTER (WHERE r.reward_id IS NOT NULL)::float / COUNT(*) FROM task_activity t LEFT JOIN rewards r ON r.source_activity_id = t.activity_id AND r.status='credited' WHERE t.task_status='Completed'", "B.Task_Activity.task_status vs reward_status (count-based)", AV_OK),
 "K25": ("SELECT transaction_type, COUNT(DISTINCT transaction_id) FROM wallet_transactions GROUP BY 1", "Missing: wallet table. Proxy: wallet_viewed events", AV_PART),
 "K26": ("SELECT unit, SUM(amount) FROM wallet_transactions WHERE direction='credit' AND status='completed' GROUP BY unit", "Missing: wallet table", AV_NO),
 "K27": ("SELECT COUNT(*), SUM(amount) FROM wallet_transactions WHERE transaction_type IN ('redemption','exchange') AND status='completed'", "Missing: wallet table. Proxy: exchange_viewed events", AV_PART),
 "K28": ("SELECT COUNT(*) FILTER (WHERE transaction_type='reversal')::float / COUNT(*) FROM wallet_transactions", "Missing: wallet table", AV_NO),
 "K29": ("SELECT COUNT(*) FROM rewards r LEFT JOIN wallet_transactions w ON w.reference_id = r.reward_id AND w.status='completed' WHERE r.status='credited' AND w.transaction_id IS NULL", "Missing: wallet table and reward-to-ledger link", AV_NO),
 "K30": ("SELECT COUNT(withdrawal_id) FROM withdrawals WHERE requested_at IN period", "Missing: withdrawals table", AV_NO),
 "K31": ("SELECT COUNT(*) FROM withdrawals WHERE status='completed' AND finalized_at IN period", "Missing: withdrawals table", AV_NO),
 "K32": ("SELECT COUNT(*) FROM withdrawals WHERE status IN ('requested','processing')", "Missing: withdrawals table", AV_NO),
 "K33": ("SELECT reason_category, COUNT(*) FROM withdrawals WHERE status='rejected' GROUP BY 1", "Missing: withdrawals table", AV_NO),
 "K34": ("SELECT COUNT(*) FROM withdrawals WHERE status='reversed'", "Missing: withdrawals table", AV_NO),
 "K35": ("SELECT PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY finalized_at - requested_at) FROM withdrawals WHERE status='completed'", "Missing: withdrawals table", AV_NO),
 "K36": ("SELECT COUNT(*) FILTER (WHERE status='completed')::float / COUNT(*) FILTER (WHERE status IN ('completed','rejected','reversed')) FROM withdrawals WHERE requested_at < :asof - INTERVAL '14 day'", "Missing: withdrawals table", AV_NO),
 "K37": ("SELECT unit, SUM(final_amount) FROM withdrawals WHERE status='completed' GROUP BY unit", "Missing: withdrawals table", AV_NO),
 "K38": ("SELECT method, COUNT(*)::float / SUM(COUNT(*)) OVER () FROM withdrawals GROUP BY 1", "Missing: withdrawals table", AV_NO),
 "K39": ("SELECT COUNT(DISTINCT referral_id) FROM referrals WHERE created_at IN period", "Missing: referrals table. Proxy: referral_created events (not unique referrals)", AV_PART),
 "K40": ("SELECT COUNT(*) FROM referrals WHERE registered_at IS NOT NULL", "Proxy: users with acquisition_source='Referral'", AV_PART),
 "K41": ("SELECT COUNT(*) FROM referrals WHERE activated_at IS NOT NULL", "Missing: referrals table and an activation rule", AV_NO),
 "K42": ("SELECT COUNT(*) FILTER (WHERE status='converted')::float / COUNT(*) FROM referrals WHERE created_at < :asof - INTERVAL '30 day'", "Missing: referrals table and a conversion rule", AV_NO),
 "K43": ("SELECT COUNT(ticket_id) FROM support_tickets WHERE created_at IN period", "Missing: tickets. Proxy: sessions with entry_point 'Help/Support'", AV_PART),
 "K44": ("SELECT issue_category, COUNT(*) FROM support_tickets GROUP BY 1", "Missing: tickets", AV_NO),
 "K45": ("SELECT COUNT(*), COUNT(DISTINCT user_id) FROM help_events WHERE event_name='help_article_viewed'", "Proxy: sessions with entry_point 'Help/Support' (no article events)", AV_PART),
 "K46": ("SELECT 1 - COUNT(*) FILTER (WHERE failed_any_hard_rule)::float / COUNT(*) FROM loaded_rows", "This audit's rules applied to the messy sheets", AV_OK),
}
F = lambda x: f"{x:,.0f}"; P = lambda x: f"{x*100:.1f}%"

def supplied_values(d):
    A, U, S, E, T = d["A:Users_1000_Clean"], d["B:01_Users_1000"], d["B:02_Sessions"], d["B:03_Feature_Events"], d["B:05_Task_Activity"]
    v = {}; end = PERIOD_END + pd.Timedelta(days=1)
    E = E.assign(ts=pd.to_datetime(E.event_datetime)); E["day"] = E.ts.dt.normalize()
    reg = pd.to_datetime(A.registration_datetime); m = reg.dt.to_period("M").value_counts().sort_index()
    v["K01"] = f"{F(A.user_id.nunique())} registered (Users_1000_Clean, master). By month: " + ", ".join(f"{k}: {n}" for k, n in m.items())
    v["K02"] = "; ".join(f"{k} {n}" for k, n in A.acquisition_source.value_counts().items())
    dau = E.groupby("day").user_id.nunique(); last30 = dau[dau.index > end - pd.Timedelta(days=31)]
    v["K03"] = f"mean DAU over {len(dau)} active days {dau.mean():.1f}; last 30 days mean {last30.mean():.1f}; peak {F(dau.max())} on {dau.idxmax().date()}"
    ws = pd.Timestamp("2026-08-16"); act = E[E.ts >= ws].user_id.unique(); ureg = pd.to_datetime(U.set_index("user_id").registration_datetime)
    ret = [u for u in act if ureg.get(u, pd.Timestamp.max) < ws]
    v["K04"] = f"window 16 Aug-15 Sep: {F(len(act))} active users, {F(len(ret))} registered before the window ({P(len(ret)/max(len(act),1))})"
    aug = E[(E.ts >= "2026-08-01") & (E.ts < "2026-09-01")]; mau = aug.user_id.nunique()
    wk = E.assign(w=E.ts.dt.to_period("W")).groupby("w").user_id.nunique()
    v["K05"] = f"MAU Aug 2026 = {F(mau)}; mean WAU = {wk.mean():.1f}; last full week WAU = {F(wk.iloc[-2])}"
    v["K08"] = f"Aug 2026: mean DAU {aug.groupby('day').user_id.nunique().mean():.1f} / MAU {F(mau)} = {aug.groupby('day').user_id.nunique().mean()/mau:.3f}"
    oc = A.onboarding_status.value_counts(); v["K06"] = "; ".join(f"{k} {n}" for k, n in oc.items()) + f". Completed share {P(oc.get('Completed',0)/len(A))} (snapshot)"
    ll = pd.to_datetime(A.last_login_datetime); ina = ((ll.isna()) | (ll < end - pd.Timedelta(days=31))).sum()
    v["K07"] = f"{F(ina)} of {F(len(A))} users with no login in the 30 days to 15 Sep 2026 (includes {F(ll.isna().sum())} never logged in)"
    first = E.groupby("user_id").ts.min(); delta = (first - ureg.reindex(first.index)).dt.total_seconds() / 3600
    neg = int((delta < 0).sum()); delta = delta[delta >= 0]
    v["K09"] = f"median {delta.median():.1f} h from registration to first event across {F(len(delta))} users ({neg} users had events before their registration time and are excluded)"
    v["K10"] = "; ".join(f"{k} {n}" for k, n in A.account_status.value_counts().items())
    comp = (T.task_status == "Completed").sum(); starts = T.task_started_at.notna().sum()
    v["K11"] = f"{F(starts)} task attempts with a start time"; v["K12"] = f"{P(comp/starts)} ({F(comp)} of {F(starts)}; Pending counts as not completed)"; v["K13"] = F(comp)
    fr = T[T.task_status.isin(["Failed", "Abandoned"])].failure_reason.value_counts(); v["K14"] = "; ".join(f"{k} {P(n/len(T))}" for k, n in fr.items()) + " of all attempts"
    fu = E.groupby("feature_name").user_id.nunique().sort_values(ascending=False)
    v["K15"] = f"{len(fu)} features; top: " + ", ".join(f"{k} {n}" for k, n in fu.head(3).items()) + f"; lowest: {fu.index[-1]} {fu.iloc[-1]}"
    ad = E.groupby("user_id").day.nunique(); v["K16"] = f"{P((ad>=2).mean())} of {F(len(ad))} active users had events on 2 or more days"
    v["K17"] = f"adoption {P(fu.iloc[-1]/E.user_id.nunique())} to {P(fu.iloc[0]/E.user_id.nunique())} of {F(E.user_id.nunique())} active users across features"
    v["K18"] = f"proxy: {F((T.reward_status=='Credited').sum())} tasks with reward_status Credited (counts only)"
    v["K22"] = f"{F((T.reward_status=='Pending').sum())} tasks with reward_status Pending (no age possible)"
    cr = T[T.reward_status == "Credited"].task_category.value_counts(); v["K23"] = "proxy credited task count by category: " + "; ".join(f"{k} {n}" for k, n in cr.head(4).items())
    c = T[T.task_status == "Completed"]; v["K24"] = f"{P((c.reward_status=='Credited').mean())} of completed tasks have reward_status Credited (equal in every row, so no gap is observable)"
    v["K25"] = f"proxy: {F((E.event_name=='wallet_viewed').sum())} wallet_viewed events; no ledger rows"
    v["K27"] = f"proxy: {F((E.event_name=='exchange_viewed').sum())} exchange_viewed events; no redemption rows"
    v["K39"] = f"proxy: {F((E.event_name=='referral_created').sum())} referral_created events (events, not unique referrals)"
    v["K40"] = f"proxy: {F((U.acquisition_source=='Referral').sum())} users with acquisition_source Referral"
    um, EA, uc = d["A:Users_Messy_Audit"], d["B:10_Event_Data_Quality_Audit"], A
    mm = um.merge(uc[["user_id", "registration_datetime"]], on="user_id", how="left", suffixes=("", "_c"))
    req = ["registration_datetime", "acquisition_source", "primary_device", "email_verification_status", "onboarding_status", "age", "gender", "city"]
    bad_u = um.user_id.duplicated() | um[req].isna().any(axis=1) | pd.to_datetime(um.registration_datetime, errors="coerce").isna() | (mm.registration_datetime.notna() & (mm.registration_datetime != mm.registration_datetime_c)).values | (um.last_login_datetime.isna() & (um.account_status != "Pending Verification"))
    EAm = EA.merge(E[["event_id", "feature_name"]], on="event_id", how="left", suffixes=("", "_o"))
    bad_e = EA.event_id.duplicated() | (EA.event_status != EA.event_status.str.strip()) | (EAm.feature_name != EAm.feature_name_o).values
    v["K46"] = f"Users_Messy_Audit: {F(len(um)-bad_u.sum())} of {F(len(um))} rows pass all hard rules ({P(1-bad_u.mean())}); Event audit sheet: {F(len(EA)-bad_e.sum())} of {F(len(EA))} ({P(1-bad_e.mean())}). Messy sheets are deliberately dirty, so this is not a quality measure of VELOOP"
    hs = (S.entry_point == "Help/Support"); v["K43"] = f"proxy: {F(hs.sum())} sessions entered via Help/Support ({F(S[hs].user_id.nunique())} users)"; v["K45"] = v["K43"]
    return v

def generated_values(d, g):
    R, W, D, RF = g["rewards"], g["wallet"], g["withdrawals"], g["referrals"]; v = {}; asof = PERIOD_END + pd.Timedelta(days=1)
    R = R.assign(ca=pd.to_datetime(R.created_at))
    v["K18"] = f"{F(len(R))} reward rows"
    cr = R[R.status == "credited"]; v["K19"] = "; ".join(f"{u} {F(s)}" for u, s in cr.groupby("unit").amount.sum().items())
    rev = R[R.status == "reversed"]; v["K20"] = f"{F(len(rev))} reversal rows, amount {F(rev.amount.sum())} (mixed units, sum for formula test only)"
    v["K21"] = P(len(rev) / len(cr)); pend = R[R.status == "pending"]; v["K22"] = f"{F(len(pend))} pending, median age {(asof - pend.ca).dt.days.median():.0f} days"
    v["K23"] = "; ".join(f"{k} {F(n)}" for k, n in cr.merge(d['B:05_Task_Activity'][['activity_id','task_category']], left_on='source_activity_id', right_on='activity_id').task_category.value_counts().head(3).items())
    d_ = cr.source_activity_id.duplicated().sum(); v["K24"] = f"{d_} activities credited more than once (duplicate credits detected)"
    Wd = W.drop_duplicates("transaction_id"); v["K25"] = f"{F(Wd.transaction_id.nunique())} distinct transactions; {int(W.transaction_id.duplicated().sum())} duplicate transaction_id rows detected: " + "; ".join(f"{k} {F(n)}" for k, n in Wd.transaction_type.value_counts().items())
    wc = Wd[(Wd.direction == "credit") & (Wd.status == "completed")]; v["K26"] = "; ".join(f"{u} {F(s)}" for u, s in wc.groupby("unit").amount.sum().items())
    rd = Wd[(Wd.transaction_type.isin(["redemption", "exchange"])) & (Wd.status == "completed")]; v["K27"] = f"{F(len(rd))} redemptions, {F(rd.amount.sum())} VE"
    v["K28"] = P((Wd.transaction_type == "reversal").sum() / len(Wd))
    ok = set(Wd[Wd.status == "completed"].reference_id); gap = cr[~cr.reward_id.isin(ok)]; v["K29"] = f"{F(len(gap))} credited rewards without a completed ledger credit"
    v["K30"] = F(len(D)); v["K31"] = F((D.status == "completed").sum()); v["K32"] = F(D.status.isin(["requested", "processing"]).sum())
    v["K33"] = "; ".join(f"{k} {n}" for k, n in D[D.status == "rejected"].reason_category.value_counts().items()); v["K34"] = F((D.status == "reversed").sum())
    c_ = D[D.status == "completed"]; pt = (pd.to_datetime(c_.finalized_at) - pd.to_datetime(c_.requested_at)).dt.total_seconds() / 86400
    v["K35"] = f"median {pt.median():.2f} days, P90 {pt.quantile(.9):.2f} days (completed only)"
    old = D[pd.to_datetime(D.requested_at) < asof - pd.Timedelta(days=14)]; fin = old[old.status.isin(["completed", "rejected", "reversed"])]
    v["K36"] = f"{P((fin.status=='completed').mean())} of finalised requests older than 14 days; {F(old.status.isin(['requested','processing']).sum())} of them still open"
    v["K37"] = f"VE {F(c_.final_amount.sum())}"; v["K38"] = "; ".join(f"{k} {P(n/len(D))}" for k, n in D.method.value_counts().items())
    v["K39"] = F(len(RF)); v["K40"] = F(RF.registered_at.notna().sum()); v["K41"] = F(RF.activated_at.notna().sum())
    oldr = RF[pd.to_datetime(RF.created_at) < asof - pd.Timedelta(days=30)]; v["K42"] = f"{P((oldr.status=='converted').mean())} of {F(len(oldr))} referrals older than 30 days (rule R1 is proposed)"
    return v

def build(d, g):
    cat = pd.read_excel(ROOT / "outputs" / "VELOOP_Analytics_Foundation_Workbook.xlsx", sheet_name="08_KPI_Catalogue", header=2)
    sv, gv = supplied_values(d), generated_values(d, g); rows = []
    for _, k in cat.iterrows():
        sql, mapped, av = SPEC[k["KPI ID"]]; i = k["KPI ID"]
        rows.append({"kpi_id": i, "kpi_name": k["KPI Name"], "area": k["Area"], "business_purpose": k["Business Purpose"], "definition": k["Definition"], "exact_sql_formula": sql,
                     "required_fields": k["Required Fields"], "mapped_or_missing_in_supplied_data": mapped, "availability": av,
                     "value_on_supplied_simulated_data": sv.get(i, "" if av == AV_NO else ""), "value_on_generated_test_data (formula test only)": gv.get(i, ""),
                     "stakeholder": k["Stakeholder"], "frequency": k["Frequency"], "limitation": k["Limitation"]})
    return pd.DataFrame(rows)


MISSING = [  # area, questions that CANNOT be answered, KPIs blocked, proxy in supplied data, minimum dataset to request, what the generated test shows
 ("Rewards", "How much value is credited, per unit and feature? How often are rewards reversed or corrected? How old is the pending pool? Are any completions never credited?", "K18-K23 (amount, reversal, age)", "Task_Activity.reward_status: counts of Credited / Pending / Not Credited only; Credited equals Completed in every row",
  "rewards(reward_id, user_id, source_activity_id, amount, unit, status, created_at, credited_at, original_reward_id, reason_category)", "Formulas run: credited amount per unit, reversal rate, pending age, duplicate credits (15 planted)"),
 ("Wallet", "Do ledger totals reconcile with rewards? How much is redeemed? Are there duplicate or failed transactions?", "K25-K29", "wallet_viewed (2,172) and exchange_viewed (1,690) events only; no ledger", 
  "wallet_transactions(transaction_id, user_id, created_at, transaction_type, direction, amount, unit, status, source, reference_id, related_transaction_id)", "Formulas run: transaction mix, credit volume, redemptions, reversal share, reconciliation gap, duplicate transaction_id detection"),
 ("Withdrawals", "How many requests, how long do they take, what is the backlog and rejection mix, which methods are used?", "K30-K38", "none (no withdrawal events exist in the event stream)",
  "withdrawals(withdrawal_id, user_id, requested_amount, final_amount, unit, method, requested_at, processing_started_at, finalized_at, status, reason_category, wallet_transaction_id)", "Formulas run: queue, completion rate on finalised requests older than 14 days, median/P90 processing time, method share"),
 ("Referrals", "What share of created referrals register, activate and convert? How long does each step take?", "K39-K42 (K40 only as proxy)", "referral_created (871) and referral_shared events; 154 users with acquisition_source Referral; referral_code per user; no referrer-referred link",
  "referrals(referral_id, referrer_user_id, referred_user_id, created_at, registered_at, activated_at, status, referral_channel, activation_rule_id) plus an agreed activation rule", "Formulas run using PROPOSED rule R1 on real supplied task completions (activated = first completed task within 7 days)"),
 ("Support / content", "What do users contact support about? How fast are tickets resolved?", "K43-K45", "sessions with entry_point Help/Support (1,231)", "support_tickets(ticket_id, user_id, created_at, issue_category, status, resolved_at) and help_article_viewed events", "Not generated; no basis"),
]
def missing_frame():
    return pd.DataFrame(MISSING, columns=["area", "questions_that_cannot_be_answered_now", "kpis_blocked", "proxy_available_in_supplied_data", "minimum_dataset_to_request", "what_generated_test_data_demonstrates"])
