"""Analytical insights from the SUPPLIED simulated behaviour data. Every statement is computed here (no hand-typed numbers) and phrased
as 'in the simulated dataset'. Nothing describes actual VELOOP performance. Each insight: finding, evidence, caveat, what to check or do on real data."""
import math
import numpy as np, pandas as pd
from .config import PERIOD_END
F = lambda x: f"{x:,.0f}"; P = lambda x: f"{x*100:.1f}%"
def ztest(x1, n1, x2, n2):
    """Two-proportion z-test, two-sided p-value (normal approximation)."""
    p = (x1 + x2) / (n1 + n2); se = math.sqrt(p * (1 - p) * (1 / n1 + 1 / n2)); z = (x1 / n1 - x2 / n2) / se
    return 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

def compute(d):
    U, S, E, T = d["B:01_Users_1000"], d["B:02_Sessions"], d["B:03_Feature_Events"], d["B:05_Task_Activity"]
    end = PERIOD_END + pd.Timedelta(days=1); tabs, ins = {}, []
    T = T.assign(done=(T.task_status == "Completed"), st=pd.to_datetime(T.task_started_at), ct=pd.to_datetime(T.task_completed_at))
    E = E.assign(ts=pd.to_datetime(E.event_datetime)); S = S.assign(s0=pd.to_datetime(S.session_start))
    # I1 completion by category
    g = T.groupby("task_category").agg(attempts=("activity_id", "count"), completed=("done", "sum")); g["completion_rate"] = g.completed / g.attempts
    g["abandoned"] = T[T.task_status == "Abandoned"].groupby("task_category").size() / g.attempts; g["failed"] = T[T.task_status == "Failed"].groupby("task_category").size() / g.attempts
    g["pending"] = T[T.task_status == "Pending"].groupby("task_category").size() / g.attempts; g = g.sort_values("completion_rate"); tabs["task_completion_by_category"] = g.reset_index()
    lo, hi = g.iloc[0], g.iloc[-1]
    ins.append(("I1", "Task completion differs by task type", f"In the simulated dataset completion ranges from {P(lo.completion_rate)} ({g.index[0]}) to {P(hi.completion_rate)} ({g.index[-1]}) across {len(g)} task types; overall {P(T.done.mean())} of {F(len(T))} attempts.",
                f"The gap is {(hi.completion_rate-lo.completion_rate)*100:.1f} percentage points; two-proportion test best vs worst p = {ztest(hi.completed, hi.attempts, lo.completed, lo.attempts):.2f}, so it is {'unlikely to be' if ztest(hi.completed, hi.attempts, lo.completed, lo.attempts) < 0.05 else 'not distinguishable from'} noise.", "On real data rank task types by completion and abandonment; investigate the lowest before adding new tasks of that type."))
    # I2 device
    dv = T.groupby("device").agg(attempts=("activity_id", "count"), completed=("done", "sum")); dv["completion_rate"] = dv.completed / dv.attempts; tabs["task_completion_by_device"] = dv.reset_index()
    ins.append(("I2", "Completion by device", "In the simulated dataset: " + "; ".join(f"{k} {P(r.completion_rate)} ({F(r.attempts)} attempts)" for k, r in dv.sort_values("completion_rate").iterrows()) + ".",
                f"macOS vs all other devices: two-proportion test p = {ztest(int(dv.loc['macOS','completed']), int(dv.loc['macOS','attempts']), int(dv.completed.sum() - dv.loc['macOS','completed']), int(dv.attempts.sum() - dv.loc['macOS','attempts'])):.3f}; Windows and macOS have far fewer attempts so their rates are noisier.", "Segment every task KPI by device; a platform with a much lower rate suggests a client-side problem."))
    # I3 start/finish pairing (investigated: ratios > 1 are not a dedup artefact; events do not pair inside sessions)
    pairs = [("ad_started", "ad_completed"), ("tap_started", "tap_completed"), ("captcha_started", "captcha_completed"), ("spin_started", "spin_completed"), ("mission_started", "mission_completed"), ("mining_started", "mining_stopped")]
    key = ["user_id", "session_id", "event_name", "event_datetime"]; Ed = E.drop_duplicates(key); rows = []
    for a_, b_ in pairs:
        ea, eb = E[E.event_name == a_], E[E.event_name == b_]; da, db = Ed[Ed.event_name == a_], Ed[Ed.event_name == b_]
        first_start = ea.groupby("session_id").ts.min(); fin = eb.assign(first_start=eb.session_id.map(first_start))
        paired = (fin.first_start.notna() & (fin.ts >= fin.first_start)).mean()
        rows.append({"started": a_, "finished": b_, "started_events": len(ea), "finished_events": len(eb), "ratio_raw": len(eb) / len(ea), "started_after_dedup": len(da), "finished_after_dedup": len(db), "ratio_after_dedup": len(db) / len(da),
                     "event_ids_duplicated": int(E.event_id.duplicated().sum()), "sessions_with_finish_but_no_start": len(set(eb.session_id) - set(ea.session_id)), "sessions_with_finish": eb.session_id.nunique(),
                     "finish_events_with_earlier_start_in_same_session": paired})
    fun = pd.DataFrame(rows); tabs["event_pairing_investigation"] = fun
    over = fun[fun.ratio_after_dedup > 1.0]; pr = fun.finish_events_with_earlier_start_in_same_session
    ins.append(("I3", "Start and finish events do not pair, so event-based funnels are invalid", f"Raw finished/started ratios exceed 1.0 for {', '.join(over.finished)} and this is not a duplicate artefact: event_id is unique ({int(E.event_id.duplicated().sum())} repeats) and the ratios still exceed 1.0 after removing {len(E)-len(Ed)} content-duplicate rows. The real problem is pairing: only {P(pr.min())} to {P(pr.max())} of finish events have an earlier start in the same session, and for example {int(fun.sessions_with_finish_but_no_start.iloc[0])} of {int(fun.sessions_with_finish.iloc[0])} sessions with {fun.finished.iloc[0]} have no {fun.started.iloc[0]} at all.",
                "The finished/started ratio is NOT a valid completion rate for this data because the numerator and denominator are different events in different sessions; the denominator logic would need a shared task_activity_id.", "Give every start and its outcome the same task_activity_id, emit them in order, and test that each finish has exactly one earlier start; until then report task KPIs from Task_Activity, not from event ratios."))
    # I4 pending tasks
    pend = T[T.task_status == "Pending"]; age = (end - pend.st).dt.days
    ins.append(("I4", "Pending task attempts are not resolving", f"{F(len(pend))} attempts ({P(len(pend)/len(T))}) are Pending with reward_status Pending; {F((age>30).sum())} of them started more than 30 days before 15 Sep 2026 (median age {age.median():.0f} days).",
                "Pending may be a valid state for third-party validation; the data has no pending reason or expiry.", "Define a maximum pending time and an expiry state; report the pending pool and its age (KPI K22) so unresolved rewards are visible."))
    # I5 cohort week2 return + activation by source
    first_reg = pd.to_datetime(U.set_index("user_id").registration_datetime); ev = E.merge(first_reg.rename("reg"), left_on="user_id", right_index=True)
    ev["days"] = (ev.ts - ev.reg).dt.total_seconds() / 86400; elig = first_reg[first_reg <= end - pd.Timedelta(days=14)].index
    ret = ev[(ev.days >= 7) & (ev.days < 14)].user_id.unique(); U2 = U[U.user_id.isin(elig)].assign(ret=lambda x: x.user_id.isin(ret))
    bysrc = U2.groupby("acquisition_source").ret.agg(["mean", "count"]).sort_values("mean"); bysrc.columns = ["week2_return_rate", "users"]
    bymon = U2.assign(m=pd.to_datetime(U2.registration_datetime).dt.to_period("M").astype(str)).groupby("m").ret.agg(["mean", "count"]); bymon.columns = ["week2_return_rate", "users"]
    tabs["week2_return_by_source"] = bysrc.reset_index(); tabs["week2_return_by_registration_month"] = bymon.reset_index()
    ins.append(("I5", "Week-2 return by acquisition source", f"Among {F(len(U2))} users registered at least 14 days before period end, {P(U2.ret.mean())} had an event 7 to 14 days after registering; by source it ranges from {P(bysrc.week2_return_rate.iloc[0])} ({bysrc.index[0]}) to {P(bysrc.week2_return_rate.iloc[-1])} ({bysrc.index[-1]}).",
                "Small sources (Telegram, WhatsApp) have under 100 users, so differences are uncertain.", "Report retention by acquisition source and registration month on real data to judge channel quality, not just volume."))
    # activation
    comp = T[T.done].merge(first_reg.rename("reg"), left_on="user_id", right_index=True); comp["d"] = (comp.ct - comp.reg).dt.total_seconds() / 86400
    act7 = comp[(comp.d >= 0) & (comp.d <= 7)].user_id.unique(); Ua = U[U.user_id.isin(first_reg[first_reg <= end - pd.Timedelta(days=7)].index)].assign(a=lambda x: x.user_id.isin(act7))
    asrc = Ua.groupby("acquisition_source").a.agg(["mean", "count"]).sort_values("mean"); asrc.columns = ["completed_task_within_7d", "users"]; tabs["activation_7d_by_source"] = asrc.reset_index()
    ins.append(("I6", "Activation (first completed task within 7 days)", f"In the simulated dataset {P(Ua.a.mean())} of {F(len(Ua))} users completed a task within 7 days of registering; by source {P(asrc.completed_task_within_7d.iloc[0])} ({asrc.index[0]}) to {P(asrc.completed_task_within_7d.iloc[-1])} ({asrc.index[-1]}).",
                "The 7-day window is a proposed activation rule, not a VELOOP definition.", "Agree an activation definition with product; then track activation by source and by onboarding status."))
    # I7 concentration + never active
    ue = E.groupby("user_id").size().sort_values(ascending=False); top = ue.head(int(len(U) * 0.1)).sum() / ue.sum(); never = len(set(U.user_id) - set(S.user_id))
    tabs["events_per_user_distribution"] = ue.describe().rename("events_per_user").reset_index()
    ins.append(("I7", "Activity concentration and never-active users", f"The top 10% of users ({F(len(U)*0.1)}) produce {P(top)} of events; median events per active user {ue.median():.0f}; {never} registered users ({P(never/len(U))}) have no session at all.",
                "Whether this concentration is high or normal needs a benchmark that is not available; the dataset is simulated.", "Track the share of registered users who never start a session and the activity share of the top decile; both guide onboarding and anti-abuse work."))
    # I8 entry point -> tasks per session
    tps = T.groupby("session_id").size(); S2 = S.assign(tasks=S.session_id.map(tps).fillna(0)); ep = S2.groupby("entry_point").agg(sessions=("session_id", "count"), tasks_per_session=("tasks", "mean"), median_duration_s=("session_duration_seconds", lambda x: pd.to_numeric(x).median())).sort_values("tasks_per_session")
    tabs["sessions_by_entry_point"] = ep.reset_index()
    ins.append(("I8", "Entry point and tasks per session", f"Tasks per session by entry point range from {ep.tasks_per_session.iloc[0]:.2f} ({ep.index[0]}) to {ep.tasks_per_session.iloc[-1]:.2f} ({ep.index[-1]}); {P(ep.loc['Help/Support','sessions']/len(S))} of sessions start from Help/Support.",
                "Differences between entry points are small in this data.", "Compare entry points on real data; a high Help/Support share would indicate friction worth a support-content review (KPI K43/K45)."))
    # I9 hour of day
    hr = S.s0.dt.hour.value_counts().sort_index(); wk = S.s0.dt.dayofweek.value_counts().sort_index(); tabs["sessions_by_hour"] = hr.rename("sessions").reset_index().rename(columns={"index": "hour", "s0": "hour"})
    sh = hr / hr.sum(); flat = (sh.max() - sh.min()) < 0.02
    ins.append(("I9", "When users are active", (f"Hourly activity is almost flat: every hour holds between {P(sh.min())} and {P(sh.max())} of sessions (even share would be {P(1/24)}), so there is no clear peak. " if flat else f"Sessions peak at {hr.idxmax():02d}:00 ({P(sh.max())}). ") +
                f"Weekday vs weekend share is {P(wk[:5].sum()/wk.sum())} / {P(wk[5:].sum()/wk.sum())}, close to the 71.4% / 28.6% expected from even daily activity.",
                "Timestamps may not be in the user's local time (timezone unknown, assumption A011); a flat profile can itself be a sign of generated data.", "On real data use the hourly profile to schedule notifications, support staffing and maintenance, after verifying timezone handling."))
    # I10 reward status vs failure
    tabs["status_x_reward_status"] = pd.crosstab(T.task_status, T.reward_status).reset_index()
    ins.append(("I10", "Rewards are binary on tasks", f"Reward status is Credited for every Completed task and Not Credited for every Abandoned or Failed one ({F((T.reward_status=='Credited').sum())} credited, {F((T.reward_status=='Not Credited').sum())} not credited, {F((T.reward_status=='Pending').sum())} pending).",
                "A perfect match means the supplied reward_status is derived from task_status, not an independent ledger record, so credit failures cannot be observed.", "Record rewards as separate ledger rows (reward_id, amount, unit) so the gap between completed and credited can be measured (KPI K24)."))
    # I11 funnel conversion view->start->complete from events (task-like)
    # I11 weekly active users: partial weeks and user-base growth
    wk = E.assign(w=E.ts.dt.to_period("W")).groupby("w").agg(active_users=("user_id", "nunique"), first=("ts", "min"), last=("ts", "max"))
    wk["week_start"] = [p.start_time for p in wk.index]; wk["days_in_period"] = [int((min(p.end_time.normalize(), PERIOD_END) - max(p.start_time, pd.Timestamp("2026-04-01"))).days + 1) for p in wk.index]
    wk["partial_week"] = wk.days_in_period < 7; rg = pd.to_datetime(U.registration_datetime)
    wk["registered_by_week_end"] = [int((rg <= min(p.end_time, PERIOD_END + pd.Timedelta(days=1))).sum()) for p in wk.index]; wk["active_share_of_registered"] = wk.active_users / wk.registered_by_week_end
    wk = wk.reset_index(drop=True); tabs["weekly_active_users"] = wk[["week_start", "days_in_period", "partial_week", "active_users", "registered_by_week_end", "active_share_of_registered"]]
    full = wk[~wk.partial_week]; par = wk[wk.partial_week]
    ins.append(("I11", "Weekly active users rise with the user base; first and last weeks are partial", f"Among {len(full)} complete weeks active users grow from {int(full.active_users.iloc[0])} to {int(full.active_users.iloc[-1])}, but registered users also grow from {int(full.registered_by_week_end.iloc[0])} to {int(full.registered_by_week_end.iloc[-1])}; the active share goes from {P(full.active_share_of_registered.iloc[0])} to {P(full.active_share_of_registered.iloc[-1])}. The apparent drop in the last point ({int(par.active_users.iloc[-1])}) is not a decline: that week covers only {int(par.days_in_period.iloc[-1])} of 7 days (the first week covers {int(par.days_in_period.iloc[0])}).",
                "Counts of active users alone mix growth of the base with engagement; partial weeks must not be compared with full weeks.", "Report weekly active users only for complete weeks, show partial weeks separately, and add active share of registered users so growth in the base is not read as engagement."))
    return ins, tabs

def to_frame(ins):
    return pd.DataFrame(ins, columns=["insight_id", "title", "finding_simulated_data_only", "caveat", "what_to_check_or_do_on_real_data"])
