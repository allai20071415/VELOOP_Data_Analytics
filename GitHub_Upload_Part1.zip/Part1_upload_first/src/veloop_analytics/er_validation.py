"""Test every relationship drawn in the ER diagram against the data that exists. Result per relationship:
PASS (supplied data), PASS (generated data only), FAIL, NOT TESTABLE. Generated data cannot prove a real VELOOP design; it only checks the model is internally coherent."""
import pandas as pd

def run(d, g):
    U, S, E, T, M, DA = d["B:01_Users_1000"], d["B:02_Sessions"], d["B:03_Feature_Events"], d["B:05_Task_Activity"], d["B:06_Milestones"], d["B:04_Daily_Activity"]
    R, W, D, F = g["rewards"], g["wallet"], g["withdrawals"], g["referrals"]; rows = []
    def add(parent, child, card, data, test, viol, notes, supported=True, status=None):
        res = status or ("PASS" if viol == 0 else "FAIL"); label = res + (" (supplied data)" if data == "supplied" and res == "PASS" else " (generated data only)" if data == "generated" and res == "PASS" else "")
        rows.append({"parent": parent, "child": child, "cardinality_claimed": card, "data_used": data, "test": test, "violations": viol, "result": label, "notes": notes})
    fk = lambda child, col, parent, pcol: int((~child[col].dropna().isin(parent[pcol])).sum())
    add("users", "task_activity", "1:N", "supplied", "task_activity.user_id exists in users (B)", fk(T, "user_id", U, "user_id"), "A and B user tables conflict on attributes; behaviour joins use B users (assumption E1).")
    ids = T.groupby("task_id").task_category.nunique(); add("tasks", "task_activity", "1:N", "supplied", "each task_id maps to one task_category (needed to derive a tasks catalogue)", int((ids > 1).sum()),
        "No tasks table was supplied and task_id is not consistent, so the tasks entity is PROPOSED and cannot be derived (assumption E2).", status="FAIL")
    add("users", "sessions", "1:N", "supplied", "sessions.user_id exists in users", fk(S, "user_id", U, "user_id"), "")
    add("users", "feature_events", "1:N", "supplied", "feature_events.user_id exists in users", fk(E, "user_id", U, "user_id"), "")
    m = E.merge(S[["session_id", "user_id"]], on="session_id", suffixes=("", "_s")); add("sessions", "feature_events", "1:N", "supplied", "feature_events.session_id exists in sessions AND event user = session user",
        fk(E, "session_id", S, "session_id") + int((m.user_id != m.user_id_s).sum()), "Both orphan and user-consistency violations counted.")
    mt = T.merge(S[["session_id", "user_id"]], on="session_id", suffixes=("", "_s")); add("sessions", "task_activity", "1:N", "supplied", "task_activity.session_id exists in sessions AND task user = session user",
        fk(T, "session_id", S, "session_id") + int((mt.user_id != mt.user_id_s).sum()), "")
    cr = R[R.status == "credited"]; dupact = int(cr.source_activity_id.duplicated().sum()); add("task_activity", "rewards", "1:0..1", "generated", "at most one credited reward per source activity", dupact,
        f"{dupact} activities are credited twice (planted duplicates). A UNIQUE rule on (source_activity_id, status='credited') is required. Supplied data has only reward_status, so 1:1 cannot be tested (assumption E3).")
    add("users", "rewards", "1:N", "generated", "rewards.user_id exists in users", fk(R, "user_id", U, "user_id"), "")
    perw = g["wallet"][g["wallet"].transaction_type == "reward_credit"].drop_duplicates("transaction_id").groupby("reference_id").size()
    add("rewards", "wallet_transactions", "1:0..1", "generated", "at most one distinct reward_credit transaction per reward", int((perw > 1).sum()), f"{int(g['wallet'].transaction_id.duplicated().sum())} duplicate ledger rows (same transaction_id) exist and must be deduplicated; some credited rewards have no completed ledger credit (K29).")
    add("users", "wallet_transactions", "1:N", "generated", "wallet.user_id exists in users", fk(W, "user_id", U, "user_id"), "")
    rv = R[R.status.isin(["reversed", "corrected"])]; wr = W[W.transaction_type.isin(["reversal", "adjustment"])]
    add("rewards", "rewards (self)", "1:N", "generated", "original_reward_id of reversal/correction exists", fk(rv, "original_reward_id", R, "reward_id"), "Self-reference for reversal chains.")
    add("wallet_transactions", "wallet_transactions (self)", "1:N", "generated", "related_transaction_id of reversal/adjustment exists", fk(wr[wr.related_transaction_id.notna()], "related_transaction_id", W, "transaction_id"), "")
    add("users", "withdrawals", "1:N", "generated", "withdrawals.user_id exists in users", fk(D, "user_id", U, "user_id"), "")
    wd_deb = W[W.transaction_type == "withdrawal"].drop_duplicates("transaction_id").groupby("reference_id").size(); active = D[D.status.isin(["processing", "completed", "reversed"])]; nodebit = D[D.status.isin(["requested", "rejected"])]
    viol = int(((active.withdrawal_id.map(wd_deb).fillna(0)) != 1).sum() + nodebit.withdrawal_id.isin(wd_deb.index).sum())
    add("withdrawals", "wallet_transactions", "1:1", "generated", "processing, completed and reversed withdrawals have exactly one wallet debit; requested and rejected have none", viol, "Assumption E4: the debit is created when a request enters processing.")
    refd = F[F.referred_user_id.notna()]; viol = int(F.referrer_user_id.isin(U.user_id).eq(False).sum() + (~refd.referred_user_id.isin(U.user_id)).sum() + (F.referrer_user_id == F.referred_user_id).sum() + refd.referred_user_id.duplicated().sum())
    add("users", "referrals", "1:N (referrer); 1:0..1 (referred)", "generated", "referrer and referred exist, differ, and a referred user has at most one referral", viol, "Activation/conversion rule R1 is PROPOSED (assumption E5).")
    add("users", "support_tickets", "1:N", "none", "no support table in supplied or generated data", 0, "Proposed entity only.", status="NOT TESTABLE")
    extra = [("users", "milestones", "1:N", "supplied", "milestones.user_id exists in users", fk(M, "user_id", U, "user_id"), ""),
             ("users", "daily_activity", "1:N", "supplied", "daily_activity.user_id exists in users and (user, date) is unique", fk(DA, "user_id", U, "user_id") + int(DA.duplicated(["user_id", "activity_date"]).sum()), "")]
    for e in extra: add(*e)
    return pd.DataFrame(rows)

ASSUMPTIONS = [("E1", "Behaviour tables join to the behaviour workbook's Users (B). Users_1000_Clean (A) is the master for profile attributes, and the two are never joined because their attributes conflict."),
 ("E2", "A tasks catalogue entity is proposed. The supplied data has no tasks table and task_id is inconsistent, so tasks 1:N task_activity cannot be verified."),
 ("E3", "One activity earns at most one credited reward. Supplied data cannot confirm this because it has only a derived reward_status."),
 ("E4", "The wallet debit for a withdrawal is created when the request enters processing: requested and rejected requests have none; processing, completed and reversed requests have exactly one."),
 ("E5", "Referral activation and conversion follow the PROPOSED rule R1 (first completed task within 7 days; 3 or more within 14 days)."),
 ("E6", "Cardinalities on rewards, wallet, withdrawals, referrals and support tickets are design assumptions; generated data can only show the model is coherent, not that VELOOP's system works this way."),
 ("E7", "Entities not in the supplied pack (tasks, rewards, wallet_transactions, withdrawals, referrals, support_tickets) are PROPOSED and drawn with dashed outlines.")]
