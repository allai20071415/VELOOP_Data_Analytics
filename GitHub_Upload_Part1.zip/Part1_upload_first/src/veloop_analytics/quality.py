"""Work Packages K/L: data-quality checks. Each check is a small function returning Issue objects."""
from dataclasses import dataclass, asdict, field, fields
import pandas as pd
from .config import PERIOD_END
from .relationships import cross_file_conflict

@dataclass
class Issue:
    dataset: str; field: str; issue_type: str; records: int; severity: str
    detection: str; likely_cause: str; correction: str; prevention: str; owner: str; status: str = "Open"
    rows: object = field(default=None, repr=False)   # offending records (evidence); None for table-level issues

def check_users_messy(d):
    um, uc = d["A:Users_Messy_Audit"], d["A:Users_1000_Clean"]
    out = [Issue("A:Users_Messy_Audit", "user_id", "duplicate IDs / duplicate rows", int(um.user_id.duplicated().sum()), "High",
                 f"user_id repeated; exact duplicate rows={int(um.duplicated().sum())}; IDs affected={um[um.user_id.duplicated(keep=False)].user_id.nunique()}",
                 "Double load or retry", "Keep first occurrence, quarantine copies", "UNIQUE constraint / ingestion dedup", "Engineering",
                 rows=um[um.user_id.duplicated()][["user_id", "registration_datetime"]])]
    sev = {"age": "Medium", "gender": "Low", "city": "Medium", "registration_datetime": "Critical", "acquisition_source": "Medium",
           "primary_device": "Medium", "email_verification_status": "High", "onboarding_status": "High"}
    for c, s in sev.items():
        n = int(um[c].isna().sum() - uc[c].isna().sum())
        if n:
            out.append(Issue("A:Users_Messy_Audit", c, "unexpected null in required field", n, s, f"required field null (clean baseline has {int(uc[c].isna().sum())})",
                             "Missing capture or failed write", "Backfill from source; never impute silently", "Required-field check at app + ingestion", "Engineering",
                             rows=um[um[c].isna() & ~um.user_id.isin(uc[uc[c].isna()].user_id)][["user_id", c]]))
    n = int(um.drop_duplicates("user_id").last_login_datetime.isna().sum() - uc.last_login_datetime.isna().sum())
    if n:
        out.append(Issue("A:Users_Messy_Audit", "last_login_datetime", "unexpected null", n, "Medium",
                         "null where account is not Pending Verification (all clean nulls are Pending Verification)", "Login not recorded", "Recover from login events", "Require last_login for non-pending accounts", "Engineering",
                         rows=um.drop_duplicates("user_id").pipe(lambda x: x[x.last_login_datetime.isna() & ~x.user_id.isin(uc[uc.last_login_datetime.isna()].user_id)])[["user_id", "account_status", "last_login_datetime"]]))
    n = int(pd.to_datetime(um.registration_datetime.dropna(), errors="coerce").isna().sum())
    if n:
        out.append(Issue("A:Users_Messy_Audit", "registration_datetime", "malformed date", n, "Critical", "value does not parse as a date (e.g. month 14)",
                         "Format / day-month swap", "Quarantine and correct from source", "ISO-8601 validation at ingestion", "Engineering",
                         rows=um[um.registration_datetime.notna() & pd.to_datetime(um.registration_datetime, errors="coerce").isna()][["user_id", "registration_datetime"]]))
    m = um.drop_duplicates("user_id").merge(uc, on="user_id", suffixes=("", "_c"))
    ok = pd.to_datetime(m.registration_datetime, errors="coerce").notna()
    dv = m[ok & (m.registration_datetime != m.registration_datetime_c)]
    if len(dv):
        out.append(Issue("A:Users_Messy_Audit", "registration_datetime", "value conflicts with clean baseline", len(dv), "High",
                         "valid timestamp differs from clean sheet: " + ", ".join(dv.user_id), "Manual edit / wrong source",
                         "Investigate; clean sheet is baseline only if confirmed", "Immutable registration time + audit log", "Engineering/Data",
                         rows=dv[["user_id", "registration_datetime", "registration_datetime_c"]].rename(columns={"registration_datetime_c": "clean_baseline_registration_datetime"})))
    return out

def check_users_clean(d):
    uc = d["A:Users_1000_Clean"]; out = []
    ll = pd.to_datetime(uc.last_login_datetime); n = int((ll > PERIOD_END + pd.Timedelta(days=1)).sum())
    if n: out.append(Issue("A:Users_1000_Clean", "last_login_datetime", "date after dataset period end (15 Sep 2026)", n, "Medium",
                           f"last_login > 2026-09-15 23:59:59 (max {ll.max()})", "Period end not enforced / later extract", "Define cut-off, clip or flag", "event time <= extract time", "Data",
                           rows=uc[ll > PERIOD_END + pd.Timedelta(days=1)][["user_id", "last_login_datetime"]]))
    ds = pd.to_numeric(uc.days_since_registration); n = int((ds < 0).sum())
    if n: out.append(Issue("A:Users_1000_Clean", "days_since_registration", "negative value", n, "Medium", f"< 0 (min {ds.min():.1f})",
                           "Reference date earlier than registration", "Compute from documented as-of timestamp", "Parameterised as-of date in transformation", "Data",
                           rows=uc[ds < 0][["user_id", "registration_datetime", "days_since_registration"]]))
    out.append(Issue("A:Users_1000_Clean", "(table)", "personal data present beyond need", len(uc), "High",
                     "full_name, email, age, gender, city present for every row", "Source includes profile attributes",
                     "Drop from analytics layer; keep user_id and coarse attributes", "Column-level access; drop PII at ingestion", "Data/Engineering"))
    return out

def check_users_b(d):
    U = d["B:01_Users_1000"]; dup = U[U.referral_code.duplicated(keep=False)]
    out = [Issue("B:01_Users_1000", "referral_code", "duplicate IDs (codes should be unique)", int(U.referral_code.duplicated().sum()), "High",
                 "shared by: " + "; ".join(f"{k}->{','.join(g.user_id)}" for k, g in dup.groupby("referral_code")), "Code collision", "Regenerate", "UNIQUE constraint", "Engineering",
                 rows=U[U.referral_code.duplicated()][["user_id", "referral_code"]])]
    cf = cross_file_conflict(d)
    out.append(Issue("A vs B", "user_id (cross-file)", "conflicting attributes for identical user_ids", 1000, "Critical",
                     "same 1000 IDs in both files; " + ", ".join(f"{r['field']} differs {r['users_where_A_differs_from_B']}" for r in cf),
                     "Two populations reuse the ID range", "Treat Users_1000_Clean as master (assumption A016); never join the two on attributes", "Single user master + ID governance", "Data (decision)/Engineering",
                     rows=d["A:Users_1000_Clean"].merge(U, on="user_id", suffixes=("_A", "_B"))[["user_id", "registration_datetime_A", "registration_datetime_B", "account_status_A", "account_status_B", "acquisition_source_A", "acquisition_source_B"]]))
    return out

def check_behaviour(d):
    U, S, E, D = d["B:01_Users_1000"], d["B:02_Sessions"], d["B:03_Feature_Events"], d["B:04_Daily_Activity"]
    T, M = d["B:05_Task_Activity"], d["B:06_Milestones"]; out = []
    actual = E.groupby("session_id").size().reindex(S.session_id).fillna(0).astype(int).values
    ev = S.assign(events_counted=actual)
    bad = ev[ev.events_in_session.astype(int) != ev.events_counted][["session_id", "user_id", "events_in_session", "events_counted"]]
    out.append(Issue("B:02_Sessions", "events_in_session", "aggregate cannot be reconciled with Feature_Events", len(bad), "High",
                     "events_in_session != COUNT(events)", "Independently generated aggregate", "Recompute from events", "Derive counts in transformation", "Data", rows=bad))
    noev = S[~S.session_id.isin(E.session_id)][["session_id", "user_id", "session_start"]]
    out.append(Issue("B:02_Sessions", "session_id", "sessions with no events", len(noev), "Medium",
                     "session without Feature_Events rows", "Event loss or empty sessions", "Investigate", "Session-to-event reconciliation rule", "Engineering", rows=noev))
    inactive = set(U.user_id) - set(S.user_id)
    out.append(Issue("B:01_Users_1000", "user_id", "users with no sessions/events/tasks", len(inactive), "Low", "user_id absent from Sessions",
                     "Registered, never active (plausible)", "None", "-", "Data", rows=U[U.user_id.isin(inactive)][["user_id", "registration_datetime", "account_status"]]))
    mi = M[M.user_id.isin(inactive)][["user_id", "milestone_type", "milestone_datetime"]]
    out.append(Issue("B:06_Milestones", "user_id", "milestones for users with no activity", len(mi), "Medium", "milestone rows for users absent from Sessions",
                     "Milestones generated independently", "Validate against source events", "Milestone must reference a source event", "Data", rows=mi))
    ms = M[M.session_id.isna()][["user_id", "milestone_type", "milestone_datetime"]]
    out.append(Issue("B:06_Milestones", "session_id", "missing session reference", len(ms), "Medium", "session_id null", "Not tied to a session", "Populate or document", "Required reference", "Engineering", rows=ms))
    cc, tc = pd.to_numeric(D.completed_task_count), pd.to_numeric(D.task_count)
    dc = D[cc > tc][["user_id", "activity_date", "task_count", "completed_task_count"]]
    out.append(Issue("B:04_Daily_Activity", "completed_task_count", "impossible value (completed > total)", len(dc), "High", "completed_task_count > task_count",
                     "Independent counters", "Recompute from Task_Activity", "completed <= total rule", "Data", rows=dc))
    sd = S.assign(d=pd.to_datetime(S.session_start).dt.normalize()).groupby(["user_id", "d"]).size().reset_index(name="sessions_counted")
    x = D.assign(dt=pd.to_datetime(D.activity_date)).merge(sd, left_on=["user_id", "dt"], right_on=["user_id", "d"], how="left")
    x["sessions_counted"] = x.sessions_counted.fillna(0).astype(int)
    sc = x[x.sessions_counted != pd.to_numeric(x.session_count)][["user_id", "activity_date", "session_count", "sessions_counted"]]
    out.append(Issue("B:04_Daily_Activity", "session_count", "does not match Sessions", len(sc), "Medium",
                     f"session_count != COUNT(sessions per user-day); {int((x.sessions_counted == 0).sum())} rows have no session", "Independent aggregation", "Rebuild from Sessions", "Derive aggregates from facts", "Data", rows=sc))
    g = T.groupby("task_id").task_category.agg(lambda s: ", ".join(sorted(s.unique())))
    n = T.groupby("task_id").task_category.nunique()
    tm = pd.DataFrame({"task_id": g.index, "categories": g.values, "n_categories": n.values}); tm = tm[tm.n_categories > 1]
    out.append(Issue("B:05_Task_Activity", "task_id", "one task_id mapped to several categories", len(tm), "High", f"task_id with >1 category (of {T.task_id.nunique()})",
                     "No task catalogue", "Create Tasks master table", "Catalogue + FK", "Product/Engineering", rows=tm))
    badr = ((T.task_status == "Failed") & (T.failure_reason == "User exited")) | ((T.task_status == "Abandoned") & T.failure_reason.isin(["Validation failed", "Task unavailable", "Timeout"]))
    fr = T[badr][["activity_id", "user_id", "task_status", "failure_reason"]]
    out.append(Issue("B:05_Task_Activity", "failure_reason", "status/reason contradiction", len(fr), "Medium", "Failed+'User exited' or Abandoned+system reason",
                     "Reason not constrained by status", "Define allowed reason per status", "Status-reason matrix", "Product/Data", rows=fr))
    out.append(Issue("B:05_Task_Activity", "reward amount / unit", "missing required analytical field", len(T), "High", "no reward_amount / reward_unit column",
                     "Not in structure", "Add reward_amount, reward_unit, reward_id", "Reward linkage in schema", "Engineering"))
    sq = E[E.duplicated(["session_id", "sequence_number"])][["event_id", "session_id", "sequence_number"]]
    out.append(Issue("B:03_Feature_Events", "sequence_number", "not unique within session", len(sq), "Medium", "duplicate (session_id, sequence_number)",
                     "Not a true ordering key", "Order by event_datetime + event_id", "Strictly increasing sequence", "Engineering", rows=sq))
    st = E[E.event_status == "Started"][["event_id", "event_name", "event_status"]]
    out.append(Issue("B:03_Feature_Events", "event_status", "'Started' used for view-type events", len(st), "Low", "views carry status Started",
                     "Status mixes view and attempt", "Separate event class", "Event taxonomy standard", "Product/Data", rows=st))
    return out

def check_event_audit(d):
    E, EA = d["B:03_Feature_Events"], d["B:10_Event_Data_Quality_Audit"]
    m = EA.drop_duplicates("event_id").merge(E, on="event_id", suffixes=("", "_o"))
    dup = EA[EA.event_id.duplicated()][["event_id", "user_id", "event_name"]]
    sp = EA[EA.event_status != EA.event_status.str.strip()][["event_id", "event_status"]]
    fn = m[m.feature_name != m.feature_name_o][["event_id", "feature_name", "feature_name_o"]].rename(columns={"feature_name_o": "feature_name_in_clean_events"})
    return [
        Issue("B:10_Event_Data_Quality_Audit", "event_id", "duplicate events", len(dup), "High", "same event_id and full row repeated", "Retry / double send", "Keep first by event_id", "Dedup on event_id at ingestion", "Engineering", rows=dup),
        Issue("B:10_Event_Data_Quality_Audit", "event_status", "trailing spaces / inconsistent value", len(sp), "Medium", "'success ' vs 'Success'", "Unnormalised client value", "TRIM + case-normalise", "Enum validation", "Engineering", rows=sp),
        Issue("B:10_Event_Data_Quality_Audit", "feature_name", "inconsistent capitalization", len(fn), "Medium", "differs from Feature_Events for same event_id", "Unnormalised client value", "Map to approved list", "Enum validation", "Engineering", rows=fn)]

def check_event_content_duplicates(d):
    E = d["B:03_Feature_Events"]
    cols = ["user_id", "session_id", "event_name", "event_datetime"]
    dup = E[E.duplicated(cols, keep="first")][["event_id"] + cols]
    return [Issue("B:03_Feature_Events", "event_id", "possible duplicate events (same user, session, event and time, different event_id)", len(dup), "Medium",
                  "duplicated on (user_id, session_id, event_name, event_datetime) while event_id is unique", "Retry / double send with a new event_id",
                  "Keep the first occurrence; quarantine the rest for review", "Idempotency key per user action, not per send; dedup on the business key", "Engineering", rows=dup)]

def check_dictionaries(d):
    dA = d["A:Data_Dictionary"].field_name.tolist(); miss = [c for c in d["A:Users_1000_Clean"].columns if c not in dA]
    dB = d["B:08_Data_Dictionary"]
    names = {"Users": "B:01_Users_1000", "Sessions": "B:02_Sessions", "Events": "B:03_Feature_Events", "Daily Activity": "B:04_Daily_Activity", "Tasks": "B:05_Task_Activity", "Milestones": "B:06_Milestones"}
    nB = sum(len([c for c in d[v].columns if c not in dB[dB.dataset == k].field_name.tolist()]) for k, v in names.items())
    return [Issue("A:Data_Dictionary", "(coverage)", "field in data not in dictionary", len(miss), "Low", "missing: " + ", ".join(miss), "Dictionary not updated", "Add fields", "Dictionary versioning", "Data"),
            Issue("B:08_Data_Dictionary", "(coverage)", "fields in data not in dictionary", nB, "Low", f"dictionary lists {len(dB)} fields for 6 sheets; FKs/flags undocumented", "Partial dictionary", "Complete it", "Dictionary versioning", "Data")]

def collect(d):
    issues = []
    for fn in (check_users_messy, check_users_clean, check_users_b, check_behaviour, check_event_audit, check_dictionaries, check_event_content_duplicates):
        issues += fn(d)
    return issues

def run_all(d):
    return [{"issue_id": f"DQ-{k:03d}", **{f.name: getattr(i, f.name) for f in fields(i) if f.name != "rows"}, "evidence_file": (f"evidence/DQ-{k:03d}.csv" if i.rows is not None else "table-level (no row list)")}
            for k, i in enumerate(collect(d), 1)]

def run_with_evidence(d):
    """Returns (issues table rows, {issue_id: offending-records DataFrame})."""
    iss = collect(d)
    ev = {f"DQ-{k:03d}": i.rows for k, i in enumerate(iss, 1) if i.rows is not None}
    return run_all(d), ev
