"""Run the test suite and write reproducible evidence: outputs/test_log.txt, outputs/test_results.xml and docs/TEST_EVIDENCE.md
(test case, purpose from its docstring, result, time). Run: python scripts/run_tests_with_evidence.py"""
import ast, subprocess, sys, pathlib, platform, datetime
import xml.etree.ElementTree as ET
ROOT = pathlib.Path(__file__).resolve().parents[1]; OUT = ROOT / "outputs"; OUT.mkdir(exist_ok=True)
proc = subprocess.run([sys.executable, "-m", "pytest", "-v", "--tb=short", f"--junitxml={OUT / 'test_results.xml'}", str(ROOT / "tests")], capture_output=True, text=True, cwd=ROOT)
(OUT / "test_log.txt").write_text(proc.stdout + proc.stderr)
doc = {}
for f in sorted((ROOT / "tests").glob("test_*.py")):
    for n in ast.walk(ast.parse(f.read_text())):
        if isinstance(n, ast.FunctionDef) and n.name.startswith("test_"): doc[(f.stem, n.name)] = ast.get_docstring(n) or n.name.replace("_", " ")
rows = []; root = ET.parse(OUT / "test_results.xml").getroot()
for tc in root.iter("testcase"):
    mod = tc.get("classname").split(".")[-1]; name = tc.get("name"); res = "FAIL" if tc.find("failure") is not None or tc.find("error") is not None else "SKIP (data missing)" if tc.find("skipped") is not None else "PASS"
    rows.append((mod, name, doc.get((mod, name), ""), res, float(tc.get("time"))))
n = {k: sum(1 for r in rows if r[3].startswith(k)) for k in ("PASS", "FAIL", "SKIP")}
md = ["# Test evidence", "", f"Generated {datetime.date.today()} by `python scripts/run_tests_with_evidence.py` | Python {platform.python_version()} | {platform.platform()}", "",
      f"**Result: {n['PASS']} passed, {n['FAIL']} failed, {n['SKIP']} skipped, {len(rows)} total.**", "",
      "Data-dependent tests need the two supplied workbooks in `data/raw/` and skip without them. All tests describe SIMULATED or GENERATED data; none validates production data.", "",
      "Raw outputs: `outputs/test_log.txt` (pytest -v), `outputs/test_results.xml` (JUnit). Validation workbooks: `outputs/VELOOP_KPI_Validation.xlsx` (38 SQL test cases with SQL, both results, tolerance, pass flag; 6 reconciliations), `outputs/VELOOP_ER_Validation.xlsx`.", "",
      "| Test file | Test case | What it proves | Result | Seconds |", "|---|---|---|---|---|"] + [f"| {m} | `{nm}` | {p} | {r} | {t:.2f} |" for m, nm, p, r, t in rows]
(ROOT / "docs" / "TEST_EVIDENCE.md").write_text("\n".join(md) + "\n"); print(f"{n['PASS']} passed, {n['FAIL']} failed, {n['SKIP']} skipped")
sys.exit(1 if n["FAIL"] else 0)
