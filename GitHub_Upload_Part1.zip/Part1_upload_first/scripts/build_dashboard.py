"""Build the FUNCTIONAL interactive dashboard (dashboard/index.html) from the supplied simulated behaviour data.
Only aggregates are embedded (no names, emails or row-level data). Run: python scripts/build_dashboard.py"""
import sys, json, pathlib
import pandas as pd
ROOT = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
from veloop_analytics.loaders import load_all
from veloop_analytics import quality
d = load_all(); S, E, T = d["B:02_Sessions"], d["B:03_Feature_Events"], d["B:05_Task_Activity"]
E = E.assign(ts=pd.to_datetime(E.event_datetime)); E["month"] = E.ts.dt.strftime("%Y-%m"); E["week"] = E.ts.dt.to_period("W").dt.start_time.dt.strftime("%Y-%m-%d")
S = S.assign(s0=pd.to_datetime(S.session_start)); S["month"] = S.s0.dt.strftime("%Y-%m"); S["week"] = S.s0.dt.to_period("W").dt.start_time.dt.strftime("%Y-%m-%d")
T = T.assign(st=pd.to_datetime(T.task_started_at)); T["month"] = T.st.dt.strftime("%Y-%m")
dev = sorted(E.device.dropna().unique()); months = sorted(E.month.unique())
def sel(df, device=None, month=None):
    if device and device != "All": df = df[df.device == device]
    if month and month != "All": df = df[df.month == month]
    return df
kpi = {}
for dv in ["All"] + dev:
    for mo in ["All"] + months:
        e, s, t = sel(E, dv, mo), sel(S, dv, mo), sel(T, dv, mo)
        kpi[f"{dv}|{mo}"] = [int(e.user_id.nunique()), int(len(s)), int(len(e)), int(len(t)), int((t.task_status == "Completed").sum())]
U = d["B:01_Users_1000"].assign(reg=lambda x: pd.to_datetime(x.registration_datetime))
PEND = pd.Timestamp("2026-09-15"); PSTART = pd.Timestamp("2026-04-01")
def weekly_for(dv):
    e = sel(E, dv); u = U if dv == "All" else U[U.primary_device == dv]; out = []
    for w, g in e.groupby("week"):
        ws = pd.Timestamp(w); we = ws + pd.Timedelta(days=6, hours=23, minutes=59)
        days = int((min(we.normalize(), PEND) - max(ws, PSTART)).days + 1)
        out.append([w, int(g.user_id.nunique()), days, int((u.reg <= min(we, PEND + pd.Timedelta(days=1))).sum())])
    return out
weekly = {dv: weekly_for(dv) for dv in ["All"] + dev}
cats = sorted(T.task_category.unique()); status = ["Completed", "Pending", "Abandoned", "Failed"]
tasks = {f"{dv}|{mo}": {c: [int(((x.task_category == c) & (x.task_status == s)).sum()) for s in status] for c in cats}
         for dv in ["All"] + dev for mo in ["All"] + months for x in [sel(T, dv, mo)]}
feat = {dv: sel(E, dv).groupby("feature_name").user_id.nunique().sort_values(ascending=False).to_dict() for dv in ["All"] + dev}
dq = pd.DataFrame(quality.run_all(d)).severity.value_counts().reindex(["Critical", "High", "Medium", "Low"]).fillna(0).astype(int).to_dict()
data = {"devices": dev, "months": months, "status": status, "kpi": kpi, "weekly": weekly, "tasks": tasks, "features": feat, "dq": dq}
html = r'''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>VELOOP analytics dashboard (simulated data)</title><style>
:root{--bg:#fff;--s:#eef2f8;--t:#111827;--m:#4b5563;--a:#1f3864;--b:#2563eb;--w:#991b1b;--wb:#fef2f2;--bd:#cbd5e1}
@media (prefers-color-scheme:dark){:root{--bg:#0f172a;--s:#1e293b;--t:#f1f5f9;--m:#cbd5e1;--a:#93c5fd;--b:#60a5fa;--w:#fecaca;--wb:#450a0a;--bd:#334155}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--t);font-family:"Segoe UI",Arial,sans-serif}
header{background:var(--a);color:#fff;padding:12px 18px}header h1{margin:0;font-size:1.25rem}
@media (prefers-color-scheme:dark){header{color:#0f172a}}
.ban{background:var(--wb);color:var(--w);border:1px solid var(--w);margin:12px 18px;padding:8px 12px;border-radius:8px;font-weight:600;font-size:.9rem}
.bar{display:flex;gap:14px;flex-wrap:wrap;margin:0 18px;align-items:center}label{font-size:.85rem;color:var(--m)}
select{padding:5px 8px;border-radius:6px;border:1px solid var(--bd);background:var(--s);color:var(--t)}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:14px 18px}
.card{background:var(--s);border:1px solid var(--bd);border-radius:10px;padding:10px}.card b{display:block;font-size:1.5rem;color:var(--a)}.card span{font-size:.8rem;color:var(--m)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(380px,1fr));gap:12px;margin:0 18px 24px}
.panel{background:var(--s);border:1px solid var(--bd);border-radius:10px;padding:10px;overflow-x:auto}.panel h2{font-size:.95rem;margin:0 0 6px;color:var(--a)}
svg text{fill:var(--t);font-size:11px}.note{font-size:.78rem;color:var(--m);margin:4px 0 0}.foot{margin:0 18px 24px;color:var(--m);font-size:.8rem}
</style></head><body>
<header><h1>VELOOP analytics dashboard: FUNCTIONAL demo on simulated data</h1></header>
<div class="ban">SIMULATED DATA, NOT ACTUAL VELOOP RESULTS. This dashboard is interactive and reads the supplied simulated behaviour workbook. The 7 dashboards in the blueprint are PROPOSED wireframes; this is the only one that runs.</div>
<div class="bar"><label>Device <select id="dev"></select></label><label>Month <select id="mon"></select></label><label>Weekly chart <select id="wv"><option value="n">Active users (count)</option><option value="p">% of registered users</option></select></label></div>
<div class="cards" id="cards"></div>
<div class="grid"><div class="panel"><h2>Weekly active users (device filter). Dashed = partial week</h2><div id="wk"></div><p class="note" id="wknote"></p></div>
<div class="panel"><h2>Task attempts by type and status (device + month filter)</h2><div id="tk"></div></div>
<div class="panel"><h2>Feature usage: distinct users (device filter)</h2><div id="ft"></div></div>
<div class="panel"><h2>Data quality issues found by this audit, by severity</h2><div id="dq"></div></div></div>
<p class="foot">Qualifying activity = any feature event (proposed definition). Task completion counts Pending as not completed. The last week of the weekly chart is partial. Aggregates only; no personal fields. Source: scripts/build_dashboard.py.</p>
<script>const D=__DATA__;const $=id=>document.getElementById(id);const F=n=>n.toLocaleString("en-US");
$("dev").innerHTML=["All",...D.devices].map(x=>`<option>${x}</option>`).join("");$("mon").innerHTML=["All",...D.months].map(x=>`<option>${x}</option>`).join("");
function bars(items,w=560){const h=items.length*22+10,m=Math.max(...items.map(i=>i[1]),1);return `<svg viewBox="0 0 ${w} ${h}" width="100%">`+items.map((i,k)=>`<text x="0" y="${k*22+15}">${i[0]}</text><rect x="150" y="${k*22+4}" width="${(w-230)*i[1]/m}" height="14" fill="var(--b)"/><text x="${155+(w-230)*i[1]/m}" y="${k*22+15}">${F(i[1])}</text>`).join("")+"</svg>"}
function line(rows,w=560,h=210){const pct=$("wv").value==="p",v=r=>pct?100*r[1]/r[3]:r[1],m=Math.max(...rows.map(v),1),n=rows.length,x=i=>40+(w-60)*i/Math.max(n-1,1),y=t=>h-28-(h-50)*t/m;let o=`<svg viewBox="0 0 ${w} ${h}" width="100%">`;
for(let i=1;i<n;i++){const part=rows[i][2]<7||rows[i-1][2]<7;o+=`<line x1="${x(i-1)}" y1="${y(v(rows[i-1]))}" x2="${x(i)}" y2="${y(v(rows[i]))}" stroke="var(--b)" stroke-width="2" ${part?'stroke-dasharray="5 4" opacity=".7"':""}/>`}
rows.forEach((r,i)=>{o+=`<circle cx="${x(i)}" cy="${y(v(r))}" r="3.5" fill="${r[2]<7?"var(--bg)":"var(--b)"}" stroke="var(--b)"><title>${r[0]}: ${pct?v(r).toFixed(1)+"%":F(r[1])} (${r[2]} of 7 days)</title></circle>`});
const l=rows[n-1],f=rows[0];o+=`<text x="2" y="14">${pct?m.toFixed(0)+"%":F(m)}</text><text x="40" y="${h-8}">${f[0]}</text><text x="${w-100}" y="${h-8}">${l[0]}</text><text x="${x(n-1)-95}" y="${y(v(l))-8}">partial: ${l[2]} of 7 days</text></svg>`;return o}
function render(){const dv=$("dev").value,mo=$("mon").value,k=D.kpi[dv+"|"+mo];
$("cards").innerHTML=[["Active users",F(k[0])],["Sessions",F(k[1])],["Feature events",F(k[2])],["Task attempts",F(k[3])],["Task completion (counts)",k[3]?(100*k[4]/k[3]).toFixed(1)+"% of attempts":"n/a"]].map(c=>`<div class="card"><b>${c[1]}</b><span>${c[0]}</span></div>`).join("");
$("wk").innerHTML=line(D.weekly[dv]);$("wknote").textContent="Hollow points and dashed lines are partial weeks (first week 5 of 7 days, last week 2 of 7). The count rises partly because registered users also grow; switch to % of registered users to see the active share. Percent uses registrations up to each week end.";
const t=D.tasks[dv+"|"+mo],cols=["#2563eb","#d97706","#6b7280","#b91c1c"];let rows=Object.entries(t),mx=Math.max(...rows.map(r=>r[1].reduce((a,b)=>a+b,0)),1);
$("tk").innerHTML=`<svg viewBox="0 0 560 ${rows.length*24+34}" width="100%">`+rows.map((r,i)=>{let x=130;return `<text x="0" y="${i*24+15}">${r[0]}</text>`+r[1].map((v,j)=>{const w=400*v/mx;const s=`<rect x="${x}" y="${i*24+4}" width="${w}" height="16" fill="${cols[j]}"><title>${D.status[j]}: ${v}</title></rect>`;x+=w;return s}).join("")}).join("")+D.status.map((s,j)=>`<rect x="${130+j*105}" y="${rows.length*24+12}" width="10" height="10" fill="${cols[j]}"/><text x="${144+j*105}" y="${rows.length*24+21}">${s}</text>`).join("")+"</svg>";
$("ft").innerHTML=bars(Object.entries(D.features[dv]).slice(0,15))}
$("dq").innerHTML=bars(Object.entries(D.dq));$("dev").onchange=$("mon").onchange=$("wv").onchange=render;render();</script></body></html>'''
(ROOT / "dashboard").mkdir(exist_ok=True); (ROOT / "dashboard" / "index.html").write_text(html.replace("__DATA__", json.dumps(data)))
print("dashboard built", (ROOT / "dashboard" / "index.html").stat().st_size // 1024, "KB")
