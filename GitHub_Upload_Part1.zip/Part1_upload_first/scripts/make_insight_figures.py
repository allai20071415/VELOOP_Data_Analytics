"""Charts for the insights. Run after `python run.py insights`: python scripts/make_insight_figures.py"""
import sys, pathlib
import pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
from veloop_analytics.loaders import load_all
from veloop_analytics import insights
NAVY = "#1F3864"; ins, t = insights.compute(load_all())
fig, ax = plt.subplots(2, 2, figsize=(15, 9)); fig.suptitle("Insights from the SUPPLIED SIMULATED data (not actual VELOOP results)", fontsize=14, fontweight="bold", color=NAVY)
a = ax[0, 0]; g = t["task_completion_by_category"]; a.barh(g.task_category, g.completion_rate * 100, color="#2563EB"); a.set_title("I1 Task completion rate by type (%)", loc="left", fontsize=11, color=NAVY); a.set_xlim(0, 70)
for i, v in enumerate(g.completion_rate * 100): a.text(v + .5, i, f"{v:.1f}", va="center", fontsize=9)
a = ax[0, 1]; f = t["event_pairing_investigation"]; lab = f.started + " > " + f.finished; sh = f.finish_events_with_earlier_start_in_same_session * 100
a.barh(lab, sh, color="#B91C1C"); a.set_xlim(0, 100); a.set_title("I3 finish events with an earlier start in the same session (%)", loc="left", fontsize=11, color=NAVY)
for i, (v, r) in enumerate(zip(sh, f.ratio_after_dedup)): a.text(v + 1, i, f"{v:.1f}%  (finished/started = {r:.2f})", va="center", fontsize=8)
a = ax[1, 0]; w = t["week2_return_by_source"]; a.barh(w.acquisition_source, w.week2_return_rate * 100, color="#94A3B8"); a.set_title("I5 Week-2 return by acquisition source (%)", loc="left", fontsize=11, color=NAVY)
for i, (v, n) in enumerate(zip(w.week2_return_rate * 100, w.users)): a.text(v + .5, i, f"{v:.1f} (n={n})", va="center", fontsize=9)
a.set_xlim(0, 70)
a = ax[1, 1]; wk = t["weekly_active_users"]; fu = wk[~wk.partial_week]; a.plot(fu.week_start, fu.active_users, color="#2563EB", lw=2)
for i in wk.index[wk.partial_week]:
    j = i - 1 if i > 0 else i + 1; a.plot([wk.week_start[j], wk.week_start[i]], [wk.active_users[j], wk.active_users[i]], color="#2563EB", ls="--"); a.scatter(wk.week_start[i], wk.active_users[i], facecolors="white", edgecolors="#2563EB", zorder=3)
a2 = a.twinx(); a2.plot(fu.week_start, fu.active_share_of_registered * 100, color="#D97706", lw=1.5); a2.set_ylabel("active share of registered (%)", color="#D97706")
a.set_title("I11 weekly active users (dashed = partial week) and active share", loc="left", fontsize=11, color=NAVY); a.tick_params(axis="x", rotation=30)
for x in ax.flat:
    for sp in ("top", "right"): x.spines[sp].set_visible(False)
fig.tight_layout(rect=[0, 0, 1, .95]); fig.savefig(ROOT / "figures" / "insights_overview.png", dpi=110); print("ok")
